<?php $__env->startSection('content'); ?>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div align="center">
        <h3>EFE ANALĪZE</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text)): ?>
            <p style="text-indent: 20px;" align="justify"><?php echo e($table_models_text); ?></p>
        <?php endif; ?>
    </div>


    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" EFE analīze</strong>
                    <a href="/my_page/page_efe_manage/1/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> Edit</a>
                </td>
            </tr>
        </table>

        <br>

        <table class="table-bordered" width="850px">
            <tr height="30px" style="background-color: lightgrey;">
                <td align="center" colspan="4">
                    STIPRAS PUSĒS
                </td>
            </tr>
            <tr align="center">
                <td>Faktors</td>
                <td>Svars</td>
                <td>Reitings</td>
                <td>Kopējais svārs</td>
            </tr>
            <?php if(isset($item1[0])): ?>
                <?php $i = 0; ?>
                <?php $__currentLoopData = $item1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="vertical-align: top; padding-left:10px;">
                            <?php echo e($item1->item); ?>

                        </td>
                        <td align="center">
                            <?php echo e($item1->weight); ?>

                        </td>
                        <td align="center">
                            <?php echo e($item1->rating); ?>

                        </td>
                        <td align="center">
                            <?php echo e($score1[$i]); ?>

                        </td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td><div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div></td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                </tr>
            <?php endif; ?>
    <!-- -->
            <tr height="30px" style="background-color: lightgrey;">
                <td align="center" colspan="4">
                    VĀJĀS PUSĒS
                </td>
            </tr>
            <tr align="center">
                <td>Faktors</td>
                <td>Svars</td>
                <td>Reitings</td>
                <td>Kopējais svārs</td>
            </tr>
            <?php if(isset($item2[0])): ?>
                <?php $i = 0; ?>
                <?php $__currentLoopData = $item2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="vertical-align: top; padding-left:10px;">
                            <?php echo e($item2->item); ?>

                        </td>
                        <td align="center">
                            <?php echo e($item2->weight); ?>

                        </td>
                        <td align="center">
                            <?php echo e($item2->rating); ?>

                        </td>
                        <td align="center">
                            <?php echo e($score2[$i]); ?>

                        </td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td><div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div></td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                </tr>
            <?php endif; ?>
            <tr align="center" style="border-top:3px double grey;">
                <td>Kopā:</td>
                <td><?php echo e($total_weight); ?></td>
                <td><?php echo e($total_rating); ?></td>
                <td><?php echo e($total_score); ?></td>
            </tr>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>