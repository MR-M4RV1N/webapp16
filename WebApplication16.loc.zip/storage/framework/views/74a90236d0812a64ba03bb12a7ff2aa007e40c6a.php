<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <!-- CRUD список предприятий -->
    <table width="100%">
        <tr>
            <td colspan="2"><strong>Dokumenti:</strong></td>
        </tr>
        <tr>
            <td height="10px"></td>
        </tr>
        <?php if(isset($user_firm_result[0]->firm_name)): ?>
            <?php $i = 1;?>
            <?php $__currentLoopData = $user_firm_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="30px">
                        <?php echo e($i); ?>.
                    </td>
                    <td>
                        <?php echo e($user_firm->firm_name); ?>

                    </td>
                    <td align="right" width="150px">
                        <a class="btn btn-info btn-xs" href="<?php echo e(route('firms_show',$user_firm->id)); ?>">Show</a>

                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('firms_edit',$user_firm->id)); ?>">Edit</a>

                        <?php echo Form::open(['method' => 'DELETE','route' => ['firms_destroy', $user_firm->id],'style'=>'display:inline']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php $i++ ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td>
                    Nav neviena dokumenta
                </td>
            </tr>
        <?php endif; ?>
    </table>

    <br><br>

    <table width="800px">
        <tr>
            <td>
                <a class="btn btn-success btn-xs" href="<?php echo e(route('firms_create')); ?>"> Izveidot dokumentu</a>
            </td>
        </tr>
    </table>

    <?php if(isset($user_firm_result[0]->firm_name)): ?>
        <br><br>
        <div align="center">
            <table width="800px">
                <tr>
                    <td align="center">
                        <a class="btn btn-default btn-xs" href="<?php echo e(route('page-firms')); ?>"> Stratēģijas izstrāde</a>
                    </td>
                </tr>
            </table>
        </div>
    <?php endif; ?>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.firms_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>