<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Competitors</h3>
    </div>

    <br>

    <div>
        <strong>Mans uzņēmums:</strong>
    </div>
    <br>
    <table class="table-bordered" width="100%">
        <tr height="40px">
            <td valign="middle">
                <div style="margin-left: 20px; float: left; width:30px;">
                    <img src="/images/industry.png" style="width: 30px">
                </div>
                <div style="margin-left: 60px; margin-top:3px;">
                    <?php echo e($my_firm->name); ?>

                </div>
            </td>
            <td align="center" width="70px">
                <a href="/my_page/page_competitors_crud_edit/<?php echo e($my_firm->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
        </tr>
    </table>

    <br><br>

    <div>
        <strong>Konkurenti:</strong>
    </div>
    <br>
    <table class="table-bordered" width="100%">
        <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="40px">
                <td valign="middle">
                    <div style="margin-left: 20px; float: left; width:30px;">
                        <img src="/images/industry.png" style="width: 30px">
                    </div>
                    <div style="margin-left: 60px; margin-top:3px;">
                        <?php echo e($c->name); ?>

                    </div>
                </td>
                <td align="center" width="35px">
                    <a href="/my_page/page_competitors_crud_edit/<?php echo e($c->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td align="center" width="35px">
                    <?php echo Form::open(['method' => 'DELETE','route' => ['page-competitors-crud-destroy', $c->id]]); ?>

                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <br>

    <table width="100%">
        <tr>
            <td align="center">
                <div style="margin:5px 0px 10px 0px; text-align: center;"><a href="/my_page/page_competitors_crud_create" class="btn btn-default btn-sm"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
            </td>
        </tr>
    </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>