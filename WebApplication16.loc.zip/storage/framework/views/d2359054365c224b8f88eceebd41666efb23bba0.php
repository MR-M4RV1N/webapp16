<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('alert')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <!-- CRUD список предприятий -->
    <?php echo Form::open(array('route' => ['selected-firms-update'],'method'=>'POST')); ?>

        <table width="100%">
            <tr>
                <td colspan="2"><strong>Uzņēmumu saraksts:</strong></td>
            </tr>
            <tr>
                <td height="10px"></td>
            </tr>

            <?php $__currentLoopData = $user_firm_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_firm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($user_firm->firm_name); ?>

                    </td>
                    <td>
                        <input class="form-check-input" type="radio" name="selected_firm" id="<?php echo e($user_firm->id); ?>" value="<?php echo e($user_firm->id); ?>"
                               <?php if($user_firm->id == $selected_firm_id): ?>
                                    checked
                               <?php endif; ?>
                        >
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

        <br>

        <table width="800px">
            <tr>
                <td>
                    <button type="submit" class="btn btn-default" style="margin-top:10px;">Izvēlēties</button>
                </td>
            </tr>
        </table>
    <?php echo Form::close(); ?>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.firms_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>