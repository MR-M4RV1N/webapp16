<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">

    <div style="color: #eeeeee; margin-top:50px;">
        <p style="font-family:Calibri Light; margin:0px;">
            <span class="glyphicon glyphicon-user" aria-hidden="true" style="margin-left:15px; margin-right:5px;">

            </span>
            <a href="/page_profile" style="color: #eeeeee;">
                Profils
            </a>
        </p>
    </div>

</div>