<?php $__env->startSection('content'); ?>

    <div align="center">
        <h3>Стратегии для победы в эпоху конкуренции</h3>
    </div>

    <br><br>

    <table style="border:1px solid lightgrey" width="100%" align="center">
        <tr height="50px">
            <td colspan="2" style="border-bottom:1px solid lightgrey">
                <div style="margin-left:20px;">
                    <?php if(isset($table_title)): ?>
                        <i><?php echo e($table_title); ?></i>
                    <?php else: ?>
                        <i>Список стратагем:</i>
                    <?php endif; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td colspan="2" height="10px">

            </td>
        </tr>

        <?php $i = 1; ?>
        <?php $__currentLoopData = $stratagems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stratagems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="30px">
                <td width="100px" align="right">
                    Стратагема <?php echo e($i); ?>:
                </td>
                <td>
                    <div style="margin-left:10px;">
                        <a href="/page_stratagems_show/<?php echo e($stratagems->id); ?>"><?php echo e($stratagems->title); ?></a>
                    </div>
                </td>
            </tr>
            <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td colspan="2" height="10px">

            </td>
        </tr>

    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.stratagems_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>