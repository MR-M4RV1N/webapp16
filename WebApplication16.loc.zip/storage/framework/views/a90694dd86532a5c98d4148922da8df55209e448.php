<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Competitors</h3>
    </div>

    <br>

    <?php if($competitors[0]->type == 'my_firm'): ?>
        <div align="center">
            <strong>Uzņēmuma <?php echo e($competitors[0]->name); ?> analīze</strong>
        </div>
    <?php else: ?>
        <div align="center">
            <strong>Konkurenta <?php echo e($competitors[0]->name); ?> analīze</strong>
        </div>
    <?php endif; ?>


    <br>

    <?php echo Form::open(array('route' => ['page-competitors-crud-update', $cat, $competitors[0]->id],'method'=>'POST')); ?>

    <table width="600px" align="center">
        <tr>
            <td width="80%">

                <!-- Категории -->
                <table width="100%" class="table-bordered">
                    <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr height="50px">
                            <td>
                                <div style="margin-left:20px;"><?php echo e($criteria->name); ?></div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </td>
            <td width="20%">

                <table width="100%" align="center" class="table-bordered">

                    <?php for($i = 1; $i <= 18; $i++): ?>
                        <tr height="50px">
                            <td align="center">

                                <!-- Баллы -->
                                <table width="100px" align="center">
                                    <?php $kr = 'kr'.$i; ?>
                                    <tr align="center">
                                        <td>
                                            1
                                        </td>
                                        <td>
                                            2
                                        </td>
                                        <td>
                                            3
                                        </td>
                                        <td>
                                            4
                                        </td>
                                        <td>
                                            5
                                        </td>
                                    </tr>

                                    <tr align="center">
                                        <td>
                                            <input class="form-check-input" type="radio" name="<?php echo e($kr); ?>" id="<?php echo e($kr); ?>" value="1"
                                                   <?php if($competitors[0]->$kr == '1'): ?> checked <?php endif; ?>
                                            >
                                        </td>
                                        <td>
                                            <input class="form-check-input" type="radio" name="<?php echo e($kr); ?>" id="<?php echo e($kr); ?>" value="2"
                                                   <?php if($competitors[0]->$kr == '2'): ?> checked <?php endif; ?>
                                            >
                                        </td>
                                        <td>
                                            <input class="form-check-input" type="radio" name="<?php echo e($kr); ?>" id="<?php echo e($kr); ?>" value="3"
                                                   <?php if($competitors[0]->$kr == '3'): ?> checked <?php endif; ?>
                                            >
                                        </td>
                                        <td>
                                            <input class="form-check-input" type="radio" name="<?php echo e($kr); ?>" id="<?php echo e($kr); ?>" value="4"
                                                   <?php if($competitors[0]->$kr == '4'): ?> checked <?php endif; ?>
                                            >
                                        </td>
                                        <td>
                                            <input class="form-check-input" type="radio" name="<?php echo e($kr); ?>" id="<?php echo e($kr); ?>" value="5"
                                                   <?php if($competitors[0]->$kr == '5'): ?> checked <?php endif; ?>
                                            >
                                        </td>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                    <?php endfor; ?>

                </table>

            </td>
        </tr>
    </table>

    <br><br>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-default">Atjaunot</button>
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>