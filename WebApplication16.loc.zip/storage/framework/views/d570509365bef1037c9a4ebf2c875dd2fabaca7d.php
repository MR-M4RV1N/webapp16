 <!-- 2/2 Content -->
    <!--- 3 из 4 div перед контентом -->
    <div class="col-lg-12" style="margin:0px; padding:0px;">
        <!--- 4 из 4 div-a перед контентом -->
        <div style="border:1px solid #969696; background-color: white; padding:50px 20px 50px 20px; min-height: 620px;">


