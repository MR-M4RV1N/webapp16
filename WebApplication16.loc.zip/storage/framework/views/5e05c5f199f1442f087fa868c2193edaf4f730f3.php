<?php $__env->startSection('content'); ?>

    <div>
        <strong>Список таблиц БД:</strong>
    </div>

    <br>


        <table style="margin-left:30px;" width="800px" class="table-bordered">
            <?php $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sql): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr height="30px">
                    <td>
                        <img src="images/icon-table.png" width="20px" style="margin:0px 5px 0px 5px;">
                        <?php echo e($sql->Tables_in_webapplication16); ?>

                    </td>
                    <td width="50px" align="center">edit</td>
                    <td width="50px" align="center">delete</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <table style="margin:30px 0px 0px 30px;" width="800px" height="30px">
            <tr>
                <td align="center"><div style="margin-left:10px;">create</div></td>
            </tr>
        </table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.database_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>