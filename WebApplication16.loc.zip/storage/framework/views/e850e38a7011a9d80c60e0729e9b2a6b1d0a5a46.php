<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>Abilities</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <table align="center">
        <tr>
            <td>
                <strong>Uzņēmuma <?php echo e($selected_firm_name); ?> galvenās kompetences</strong>
            </td>
            <td>
                <a href="/my_page/page_abilities_manage/" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
            </td>
        </tr>
    </table>

    <br><br>

    <table class="table-bordered" width="100%">
        <tr align="center" height="50px">
            <td>Galvenās kompetences</td>
            <td>Ilgtspējība</td>
            <td>Caurredzamība</td>
            <td>Mobilitāte</td>
            <td>Neatkārtojama</td>
        </tr>

        <?php if(isset($item[0])): ?>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr height="50px" style="font-size: x-small">
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->key_ability); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->durability); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->transparence); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->mobility); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->repeatability); ?></div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr height="50px" style="font-size: x-small">
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>