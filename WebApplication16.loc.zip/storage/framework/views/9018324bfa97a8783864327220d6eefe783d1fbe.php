<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">

    <table width="100%" height="50px">
        <tr>
            <td>
                <strong><p style="color: white">CONTENT</p></strong>
            </td>
        </tr>
    </table>

    <hr style="margin:0px 20px 20px 20px;">

    <div style="color: #eeeeee">
        <p style="font-family:Times New Roman; margin-bottom:5px;"><span class="glyphicon glyphicon-th-large" aria-hidden="true" style="margin-right:10px; padding-left: 3px"></span><a href="/admin/page_categories_strategy_index" style="color: #eeeeee;">Stratēģijas izstrāde</a></p>
    </div>

    <div style="color: #eeeeee; margin-top:20px;">
        <p style="font-family:Times New Roman; margin-bottom:5px;"><span class="glyphicon glyphicon-th" aria-hidden="true" style="margin-right:10px; padding-left: 3px"></span><a href="/page_canvas_cat/" style="color: #eeeeee;">Business Analitic Models (upcoming)</a></p>
    </div>

    <div style="color: #eeeeee; margin-top:20px;">
        <p style="font-family:Times New Roman; margin-bottom:5px;">
            <span class="glyphicon glyphicon-knight" aria-hidden="true" style="margin-right:10px; padding-left: 3px"></span>
            <a href="/admin/page_stratagems_list/" style="color: #eeeeee;">
                Stratagems
            </a>
        </p>
    </div>

    <div style="color: #eeeeee; margin-top:20px;">
        <p style="font-family:Times New Roman; margin-bottom:5px;"><span class="glyphicon glyphicon-book" aria-hidden="true" style="margin-right:10px; padding-left: 3px"></span><a href="/admin//page_theories_list/" style="color: #eeeeee;">Management theories</a></p>
    </div>
</div>