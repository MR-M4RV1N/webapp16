<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div>
        <p>Page_home content</p>
    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.home_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>