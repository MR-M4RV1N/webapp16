<?php $__env->startSection('content'); ?>

    <strong><?php echo e($content); ?></strong><br><br>

    <table>
        <?php $i = 1 ?>
        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="30px">
                    <?php echo e($i); ?>

                </td>
                <td width="300px">
                    <?php echo e($plan->firm_name); ?>

                </td>
                <td width="50px">
                    <?php echo e($plan->name); ?>

                </td>
            </tr>
            <?php $i++ ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_plans_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>