<?php $__env->startSection('content'); ?>

    <div align="center">
        <?php echo Form::open(array('route' => ['page-resources-update', $item->id],'method'=>'POST')); ?>

        <div class="form-group" align="left" style="width:700px;">
            <div align="center">
                <img src="/images/pen.png" width="50px">
                <div style="margin:20px 0px 20px 0px;">Rediģēt ierakstu:</div>
            </div>
            <input type="text" name="item" value="<?php echo e($item->item); ?>" class="form-control" style="border-radius: 0rem;">
        </div>

        <div style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-sm">Saglabāt</button>
        </div>
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>