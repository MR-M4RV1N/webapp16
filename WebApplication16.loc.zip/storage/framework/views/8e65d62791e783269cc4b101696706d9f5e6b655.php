<!--- 3 div-a для каркаса -->
<div id="page-content-wrapper">
<div class="page-content">
<div class="container-fluid">



<!--- 4 div-a перед контентом -->
<div class="container-fluid" style="min-height: 650px; background-color: #FBFBFB;">
<div class="row" >
<div class="col-lg-12" >
<div style="margin:70px 200px 30px 200px; border:1px solid #969696; background-color: white; padding:10px 20px 50px 20px;">