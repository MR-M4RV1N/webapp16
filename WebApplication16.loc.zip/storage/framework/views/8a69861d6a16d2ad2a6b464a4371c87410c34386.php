<?php $__env->startSection('content'); ?>

    <div align="center">
        <h3>Стратегии для победы в эпоху конкуренции</h3>
    </div>

    <br><br>

    <div align="center">
        <img src="/images/strategy.jpg">
    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.stratagems_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>