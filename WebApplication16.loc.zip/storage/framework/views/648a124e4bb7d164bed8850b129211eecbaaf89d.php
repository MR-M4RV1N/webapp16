<?php $__env->startSection('content'); ?>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table style="border:1px solid lightgrey" width="100%" align="center">
        <tr height="50px">
            <td colspan="4" style="border-bottom:1px solid lightgrey">
                <div style="margin-left:20px;">
                        <?php if(isset($table_title)): ?>
                            <i><?php echo e($table_title); ?></i>
                        <?php else: ?>
                            <i>Список стратагем:</i>
                        <?php endif; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td colspan="4" height="10px">

            </td>
        </tr>

        <?php $i = 1; ?>
        <?php $__currentLoopData = $stratagems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stratagems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="30px">
                <td width="50px" align="right">
                    <?php echo e($i); ?>.
                </td>
                <td>
                    <div style="margin-left:10px;">
                        <a href="/admin/page_stratagems_show/<?php echo e($stratagems->id); ?>"><?php echo e($stratagems->title); ?></a>
                    </div>
                </td>
                <td width="40px" align="center">
                    <a href="/admin/page_stratagems_edit/<?php echo e($stratagems->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td width="40px" align="left">
                    <?php echo Form::open(['method' => 'DELETE','route' => ['page-stratagems-destroy', $stratagems->id]]); ?>

                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td colspan="4" height="10px">

            </td>
        </tr>

    </table>

    <div style="margin:30px 0px 10px 0px; text-align: center;">
        <a href="/admin/page_stratagems_create" class="btn btn-default btn-xs">
            <span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>
            Add
        </a>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>