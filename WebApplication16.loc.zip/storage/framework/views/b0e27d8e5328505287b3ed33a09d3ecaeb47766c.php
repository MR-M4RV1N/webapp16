<?php $__env->startSection('content'); ?>

    <script src="<?php echo e(asset('/js/ckeditor/ckeditor.js')); ?>"
            type="text/javascript" charset="utf-8" >
    </script>

    <!-- Content -->
    <?php echo Form::open(['method' => 'POST','route' => ['categories_sub_update', $category_record_string->id, $cat]]); ?>

    <div align="center"> <!-- div для выравнивания по центру -->
        <table class="table table-bordered">
            <tr>
                <td>
                    <p style="margin-bottom:10px;"><strong>Название:</strong></p>
                    <input type="text" name="category_sub_name" value="<?php echo e($category_record_string->name); ?>" placeholder="Название подкатегори" class="form-control name_list_canvas_record" />
                </td>
            </tr>
            <tr>
                <td>
                    <p style="margin-bottom:3px;"><strong>Маршрут</strong> (необязательно)<strong>:</strong></p>
                    <table><tr><td>http://webapplication16.loc/my_page/</td><td><input type="text" name="category_sub_route" value="<?php echo e($category_record_string->route); ?>" placeholder="my_route"  class="form-control name_list_canvas_record" style="width: 300px;"/></td></tr></table>
                </td>
            </tr>
            <tr>
                <td>
                    <p style="margin-bottom:10px;"><strong>Текст:</strong></p>
                    <textarea name="category_sub_text" cols="30" rows="5"><?php echo e($category_record_string->text); ?></textarea>
                </td>
            </tr>
        </table>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->

    <script>
        CKEDITOR.replace( 'category_sub_text' );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.menu_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>