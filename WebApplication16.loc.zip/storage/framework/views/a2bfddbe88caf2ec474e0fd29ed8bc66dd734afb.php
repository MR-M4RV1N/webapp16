<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->

    <table width="100%" height="50px">
        <tr>
            <td>
                <strong><p style="color: white">Canvas Business Model</p></strong>
            </td>
        </tr>
    </table>

    <hr style="margin:0px 20px 20px 20px;">

    <div style="color: #eeeeee">
        <?php $__currentLoopData = $catt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($cat) && ($cat == $c->id)): ?>
                <p style="font-family:Times New Roman; margin-bottom:5px;"><span class=" glyphicon glyphicon-folder-open" aria-hidden="true" style="margin-right:10px;"></span><a href="/page_canvas_cat/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($c->name); ?></a></p>
            <?php else: ?>
                <p style="font-family:Times New Roman; margin-bottom:5px;"><span class=" glyphicon glyphicon-folder-close" aria-hidden="true" style="margin-right:10px;"></span><a href="/page_canvas_cat/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($c->name); ?></a></p>
            <?php endif; ?>

            <?php if(isset($subb) && ($cat == $c->id) && !empty($subb[0])): ?>
                <?php $__currentLoopData = $subb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <p style="font-family:Calibri Light; margin:0px;"><span class=" glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-left:15px; margin-right:5px;"></span><a href="/page_canvas/<?php echo e($s->link); ?>/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($s->name); ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-bottom:10px;"></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>