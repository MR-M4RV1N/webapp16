<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Starter Template for Bootstrap</title>


    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/my_css_for_test.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/breadcrumbs.css')); ?>"/>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <!-- CKEditor -->
    <script type="text/javascript" src="<?php echo asset('js/ckeditor/ckeditor.js'); ?>"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">

    <style>
        html,
        body {
            height: 100%;
            min-width: 1024px !important;
            width: auto !important;
            width: 1024px;
            background-color: #FBFBFB;
            /* The html and body elements cannot have any padding or margin. */
        }
    </style>


</head>
<body>

<!-- -------------------------------------------------- -->

        <div id="wrapper">

            <!-- Навигация слева -->
            <?php echo $__env->make('partials.blocks_test.home_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Навигация слева -->

            <!-- Меню -->
            <?php echo $__env->make('partials.blocks_test.menu_snip_before', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Меню-->

            <!-- Контент -->
            <?php echo $__env->make('partials.blocks_test.content_snip_before', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('partials.blocks_test.content_snip_after', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Контент -->

        </div>


<!-- Bootstrap core JavaScript -->
<!-- ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="../../dist/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/i18n/defaults-*.min.js"></script>

<?php echo $__env->yieldContent('scripts'); ?>
<!-- ================================================== -->


</body>
</html>


