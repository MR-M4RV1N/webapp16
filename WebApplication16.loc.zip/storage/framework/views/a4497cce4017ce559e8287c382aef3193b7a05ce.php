<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Contribution</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <table width="100%" height="200px">
        <tr>
            <td width="30%" valign="top" style="border:1px solid black">
                <div align="center" style="margin-top: 10px;">
                    Конкурентные преимущества
                    <a href="/my_page/page_contribution_manage/<?php echo e($cat); ?>/1/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
                <div style="margin-top: 10px;">
                    <?php if(isset($item1)): ?>
                        <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                            <?php $__currentLoopData = $item1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item1->item); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </td>
            <td width="5%" align="center">
                <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
            </td>
            <td width="30%" valign="top" style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Стратегия</div>
                <div style="margin-left: 20px; margin-top: 10px; font-size: x-small;">Этот пункт мы еще обсудим</div>
            </td>
            <td width="5%" align="center">
                <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
            </td>
            <td width="30%" valign="top" style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Ключевые факторы успеха</div>
                <?php if(isset($success)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $success; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $success): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($success->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <div width="100%" style="text-align:center; margin:15px 0px 15px 0px;">
        <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
    </div>

    <table width="100%" height="200px">
        <tr>
            <td valign="top" style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Организационные способности</div>
                <?php if(isset($abilities)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abilities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($abilities->key_ability); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <div width="100%" style="text-align:center; margin:15px 0px 15px 0px;">
        <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
    </div>

    <table width="100%" height="200px" style="border:1px solid lightgrey">
        <tr align="center" height="40px">
            <td style="border:1px solid lightgrey" colspan="3">
                Ресурсы
            </td>
        </tr>
        <tr valign="top" height="200px">
            <td style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Материальные</div>
                <?php if(isset($resources_1)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $resources_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($resources_1->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
            <td style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Нематериальные</div>
                <?php if(isset($resources_2)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $resources_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($resources_2->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
            <td style="border:1px solid lightgrey">
                <div align="center" style="margin-top: 10px;">Человеческие</div>
                <?php if(isset($resources_3)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $resources_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($resources_3->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>