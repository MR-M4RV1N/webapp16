<div id="sidebar-wrapper" style="">
    <div style="margin-top:50px; color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;"  onclick="location.href='/page_main'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-th-large" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">CONTENT</p></span>
    </div>
    <div style="color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;" onclick="location.href='/page_console'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-console" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">CONSOLE</p></span>
    </div>
    <div style="background-color: #4A4542; color: white; height: 70px;  text-align: center; cursor:pointer;" onclick="location.href='/page_settings'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-cog" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">SETTINGS</p></span>
    </div>
    <div style="height: 70px; color: #AAA7A0; text-align: center; cursor:pointer;" onclick="location.href='/page_media'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-hdd" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">MEDIA</p></span>
    </div>
    <div style="color: #AAA7A0; height: 70px;  text-align: center; cursor:pointer;" onclick="location.href='/page_database'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-tasks" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">DATABASE</p></span>
    </div>
</div>