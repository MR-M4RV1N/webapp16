<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h4>Тут будет заглавие!</h4><br>
        <img src="/images/Canvas/BMC1.jpg" style="width:450px;"><br>

    </div>

    <div style="margin-top:30px;">
        <p>
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
            Тут будет текст. Боольшой такой текст.
        </p>
    </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>