<?php $__env->startSection('content'); ?>

    <script src="<?php echo e(asset('/js/ckeditor/ckeditor.js')); ?>"
            type="text/javascript" charset="utf-8" >
    </script>

    <!-- Content -->
    <?php echo Form::open(array('method'=>'POST', 'route' => ['categories_sub_store', $cat])); ?>

    <div align="center"> <!-- div для выравнивания по центру -->
        <div class="form-group">
            <strong>Название подкатегории:</strong><br><br>
            <?php echo Form::text('sub_cat_name', null, array('placeholder' => 'Название подкатегории','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <textarea name="sub_cat_text" cols="30" rows="5"></textarea>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->

    <script>
        CKEDITOR.replace( 'sub_cat_text' );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.menu_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>