<?php $__env->startSection('content'); ?>

    <?php echo Form::open(array('route' => ['page-console-run'],'method'=>'POST')); ?>

        <table class="table-bordered" width="500px" align="center">
            <tr>
                <td align="center" style="background-color: grey" height="30px">
                    <strong style="color: white">Konsole</strong>
                </td>
            </tr>
            <tr height="300px">
                <td style="vertical-align: top;">
                    WebApplication16.loc 21.02.2018<br><br>

                    <table style="margin-left:20px">
                        <tr>
                            <td colspan="2">
                                file.ini@inbox.lv f:\openserver
                            </td>
                        </tr>
                        <tr>
                            <td width="20px">
                                >_
                            </td>
                            <td width="380px">
                                <?php echo e($konsole_command); ?>

                            </td>
                        </tr>
                    </table>

                    <table style="margin:0px 0px 0px 20px" width="450px">
                        <tr>
                            <td>
                                <div style="margin:10px; color: red;"><?php echo e($answer); ?></div>
                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
        </table>
    <?php echo Form::close(); ?>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.console_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>