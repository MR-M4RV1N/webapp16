<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->

    <table width="100%" height="50px">
        <tr>
            <td>
                <strong><p style="color: white">Business Analitic Models</p></strong>
            </td>
        </tr>
    </table>

    <hr style="margin:0px 20px 20px 20px;">

    <table style="color: #eeeeee;">
        <?php $__currentLoopData = $catt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($cat) && ($cat == $c->id)): ?>
                <tr>
                    <td colspan="2">
                        <p style="font-family:Times New Roman; margin-bottom:5px;"><span class=" glyphicon glyphicon-folder-open" aria-hidden="true" style="margin-right:10px;"></span><a href="/page_models_cat/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($c->name); ?></a></p>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="2">
                        <p style="font-family:Times New Roman; margin-bottom:5px;"><span class=" glyphicon glyphicon-folder-close" aria-hidden="true" style="margin-right:10px;"></span><a href="/page_models_cat/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($c->name); ?></a></p>
                    </td>
                </tr>
            <?php endif; ?>

            <?php if(isset($subb_1) && ($cat == $c->id) && !empty($subb_1[0])): ?>
                <!-- Заглавие списка -->
                <tr>
                    <td colspan="2">
                        <i style="font-family:Calibri Light; margin:0px;">Основные инструменты:</i>
                    </td>
                </tr>
                <!-- Вывод списка -->
                <?php $__currentLoopData = $subb_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td valign="top">
                            <span class=" glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-right:5px; margin-left:15px;"></span>
                        </td>
                        <td>
                            <p style="font-family:Calibri Light; font-size:small; margin:0px;"><a href="/page_models/<?php echo e($s1->link); ?>/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($s1->name); ?></a></p>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Отступ снизу -->
                    <tr>
                        <td colspan="2" height="10px">

                        </td>
                    </tr>
            <?php endif; ?>

            <?php if(isset($subb_2) && ($cat == $c->id) && !empty($subb_2[0])): ?>
                <!-- Заглавие списка -->
                <tr>
                    <td colspan="2">
                        <i style="font-family:Calibri Light; margin:0px;">Полезные инструменты:</i>
                    </td>
                </tr>
                <!-- Вывод списка -->
                <?php $__currentLoopData = $subb_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td valign="top">
                            <span class=" glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-right:5px; margin-left:15px;"></span>
                        </td>
                        <td valign="top">
                            <p style="font-family:Calibri Light; font-size:small; margin:0px;"><a href="/page_models/<?php echo e($s2->link); ?>/<?php echo e($c->id); ?>" style="color: #eeeeee;"><?php echo e($s2->name); ?></a></p>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Отступ снизу -->
                <tr>
                    <td colspan="2" height="20px">

                    </td>
                </tr>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>