<?php $__env->startSection('content'); ?>

    <div class="container">
        <!-- Example row of columns -->
        <div class="row">
            <div class="col-lg-12">
                <h4>Тестируем БД</h4>

                <hr>

                <?php $__currentLoopData = $res_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><strong><?php echo e($term->name); ?></strong></p>
                    <p><?php echo e($term->description); ?></p>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div> <!-- /container -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.my_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>