<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php echo Form::open(array('route' => ['firms_update', $id],'method'=>'POST')); ?>

    <div align="center"> <!-- div для выравнивания по центру -->
        <div class="form-group" align="left">
            <strong>Uzņēmuma nosaukums:</strong><br><br>
            <?php echo Form::text('firm_name', $user_firm_result[0]->firm_name, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" align="left">
            <strong>Uzņēmuma apraksts:</strong><br><br>
            <?php echo Form::textarea('firm_description', $user_firm_result[0]->firm_description, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Atjaunot</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.firms_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>