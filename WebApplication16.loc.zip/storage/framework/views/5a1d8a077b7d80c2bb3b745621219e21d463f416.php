<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3><?php echo e($force_name); ?></h3>
    </div>

    <br>

    <?php echo Form::open(array('route' => ['page-forces-crud-update', $cat, $force_cat],'method'=>'POST')); ?>

    <table width="600px" align="center">
        <tr>
            <td>

                <?php if(isset($force)): ?>
                    <div class="form-group">
                        <label for="ietekme">Spēka ietekme:</label>
                        <select id="ietekme" class="form-control" name="ietekme">
                            <option <?php if($force->ietekme == 'ZEMA IETEKME"'): ?> selected="selected" <?php endif; ?> value="ZEMA IETEKME">ZEMA</option>
                            <option <?php if($force->ietekme == 'VIDĒJA IETEKME'): ?> selected="selected" <?php endif; ?> value="VIDĒJA IETEKME">VIDĒJA</option>
                            <option <?php if($force->ietekme == 'LIELA IETEKME'): ?> selected="selected" <?php endif; ?> value="LIELA IETEKME">LIELA</option>
                        </select>
                    </div>
                <?php else: ?>
                    <div class="form-group">
                        <label for="ietekme">Spēka ietekme:</label>
                        <select id="ietekme" class="form-control" name="ietekme">
                            <option value="ZEMA IETEKME">ZEMA</option>
                            <option value="VIDĒJA IETEKME">VIDĒJA</option>
                            <option value="LIELA IETEKME">LIELA</option>
                        </select>
                    </div>
                <?php endif; ?>

            </td>
        </tr>
    </table>

    <br><br>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-default">Atjaunot</button>
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>