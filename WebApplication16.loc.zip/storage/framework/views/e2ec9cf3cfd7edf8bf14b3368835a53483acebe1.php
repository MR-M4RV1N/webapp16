<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>Uzņēmuma novērtēšana</h3>
    </div>

    <br><br>

    <?php echo Form::open(array('route' => ['page-description-first-store'],'method'=>'POST')); ?>

    <div class="form-group" align="left">
        <strong>Uzņēmuma nosaukums:</strong><br>
        <?php echo Form::text('firm_name', null, array('placeholder' => 'Ievadiet tekstu', 'class' => 'form-control')); ?>

    </div>

    <div class="form-group" align="left">
        <strong>Uzņēmuma apraksts:</strong><br>
        <?php echo Form::textarea('firm_description', null, array('name'=>'firm_description','id'=>'firm_description')); ?>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-default">Pievienot</button>
    </div>

    <br><br><hr>
    <?php echo Form::close(); ?>


    <script>
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace( 'firm_description' );
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>