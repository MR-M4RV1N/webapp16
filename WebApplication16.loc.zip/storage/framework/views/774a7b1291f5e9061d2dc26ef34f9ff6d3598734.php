<?php $__env->startSection('content'); ?>

    <div align="center">
        <h3><?php echo e($theory_cat_title->category); ?></h3>
    </div>

    <br><br>


    <?php $__currentLoopData = $theories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $i = 1; ?>
        <table width="100%" align="center" style="margin-bottom: 30px;">

            <tr height="30px">
                <td>
                    <div style="margin-left:10px;">
                        <a href="/page_theories_show/<?php echo e($theory_cat_title->id); ?>/<?php echo e($theories->id); ?>"><h4><?php echo e($theories->title); ?></h4></a>
                    </div>
                </td>
            </tr>

            <tr height="30px">
                <td>
                    <table style="margin-left:10px;">
                        <tr>
                            <td style="padding-right:5px;"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span></td>
                            <td style="padding-right:30px; font-size: x-small; "><?php echo e($theories->created_at); ?></td>

                            <td style="padding-right:5px;"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span></td>
                            <td style="padding-right:30px; font-size: x-small; "><?php echo e($theories->updated_at); ?></td>

                            <td style="padding-right:5px;"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></td>
                            <td style="padding-right:30px; font-size: x-small; "><?php echo e($theories->author); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr height="30px">
                <td>
                    <div style="margin-left:10px;">
                        <?php echo e($theories->description); ?>

                    </div>
                </td>
            </tr>

            <tr>
                <td height="10px">
                    <div style="margin-top:10px; margin-left:10px;">
                        <button type="submit" class="btn btn-default btn-sm">ЧИТАТЬ ДАЛЕЕ</button>
                    </div>
                </td>
            </tr>
        </table>

        <hr style="border-top: 1px solid lightgrey;">

        <?php $i++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.theories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>