<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>DŽONA SKOULZA TESTS</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" attīstības stratēģijas virziens</strong>
                </td>
            </tr>
        </table>
        <br><br>


        <?php echo Form::open(array('route' => ['page-skoulz-update', $cat, $sub],'method'=>'POST')); ?>

        <div align="left" style="margin-bottom:10px;">
            <strong>Соответствие:</strong>
        </div>

        <table width="100%">
            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_1" value="1"
                               <?php if($select[0]['select_1'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    1. Стратегия должна разрешать стратегическую проблему, быть в состоянии справиться с угрозой извне.
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_2" value="1"
                               <?php if($select[0]['select_2'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    2. Стратегия должна опираться на ресурсы и способности.
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_3" value="1"
                               <?php if($select[0]['select_3'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    3. Стратегия должна соответствовать целям организации в виде требуемых значений показателей.
                </td>
            </tr>
        </table>

        <br>

        <div align="left" style="margin-bottom:10px;">
            <strong>Осуществимость:</strong>
        </div>

        <table width="100%">
            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_4" value="1"
                               <?php if($select[0]['select_4'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    1. Имеется ли достаточно ресурсов для реализации данной стратегии?
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_5" value="1"
                               <?php if($select[0]['select_5'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    2. В состоянии ли филиал достичь необходимого уровня операционных показателей?
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_6" value="1"
                               <?php if($select[0]['select_6'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    3. Как будут реагировать конкуренты и как мы будем отвечать на их действия?
                </td>
            </tr>
        </table>

        <br>

        <div align="left" style="margin-bottom:10px;">
            <strong>Приемлемость:</strong>
        </div>

        <table width="100%">

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_7" value="1"
                               <?php if($select[0]['select_7'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    1. Какова будет финансовая эффективность компании?
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_8" value="1"
                               <?php if($select[0]['select_8'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    2. Существует ли риск ухудшения взаимоотношений компании с ЗС?
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_9" value="1"
                               <?php if($select[0]['select_9'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    3. Каково будет влияние предлагаемой стратегии на внутренние системы и процессы?
                </td>
            </tr>
        </table>

        <div width="850px" style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-xs">Submit</button>
        </div>
        <?php echo Form::close(); ?>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>