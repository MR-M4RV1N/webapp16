<?php $__env->startSection('content'); ?>

    <div align="center">
        <h4>PRIEKŠLIKUMI - <?php echo e($table_title); ?></h4>
    </div>

    <br><br>

    <div>
        <p style="text-indent: 20px;" align="justify">
            <?php echo e($theory->theory); ?>

        </p>
    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>