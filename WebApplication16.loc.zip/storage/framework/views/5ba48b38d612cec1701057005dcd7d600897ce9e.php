<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <!-- Content -->
    <?php echo Form::open(array('route' => ['svid_ife_crud_update', $cat, $svid_item_id],'method'=>'POST')); ?>

    <div align="left"> <!-- div для выравнивания по центру -->
        <div class="form-group" align="left">
            <strong>Elements:</strong>
            <?php echo Form::text('darbibas_kriterijs', $svid_item_item->darbibas_kriterijs, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group">
            <strong>Kategorija:</strong>
            <?php echo Form::select('category', array('s' => 'Stiprā puse (s)', 'v' => 'Vajā puse (v)'), $svid_item_item->category, ['class' => 'form-control']);; ?>

        </div>

        <hr>

        <div class="form-group">
            <strong>Nozimīguma līmenis:</strong>
            <?php echo Form::select('nozimiguma_limenis', array('1' => '1–nozīmīgs', '2' => '2-ļoti nozīmīgs', '3' => '3-izšķiroša nozīme'), $svid_item_item->nozimiguma_limenis, ['class' => 'form-control']);; ?>

        </div>

        <div class="form-group">
            <strong>Vertējums salidzinājuma ar konkurentiem:</strong>
            <?php echo Form::number('vertejums_salidzinijuma_ar_konkurentiem', $svid_item_item->vertejums_salidzinijuma_ar_konkurentiem, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Velamais vertējums pēc 4 gadiem:</strong>
            <?php echo Form::number('velamais_vertejums_pec_4_gadiem', $svid_item_item->velamais_vertejums_pec_4_gadiem, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Kopejais ēsošais vertējums:</strong>
            <?php echo Form::number('kopejais_esosais_vertejums', $svid_item_item->kopejais_esosais_vertejums, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Kopejais vēlamais vertējums:</strong>
            <?php echo Form::number('kopejais_velamais_vertejums', $svid_item_item->kopejais_velamais_vertejums, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>


        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Atjaunot</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>