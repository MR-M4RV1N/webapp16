<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3><?php echo e($page_title); ?></h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <p style="text-indent: 20px;" align="justify"><?php echo e($table_models_text->text); ?></p>
        <?php endif; ?>
    </div>

    <table class="table-bordered" width="95%" height="200px" align="center">
        <tr height="40px">
            <td align="center">
                Stipro pušu izmantošanas priekšlikumi
                <a href="/my_page/page_suggestions_manage/1/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
        </tr>
        <tr>
            <td valign="top">
                <?php if(isset($item1)): ?>
                    <ul style="font-size: small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item1->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <br><br>

    <table class="table-bordered" width="95%" height="200px" align="center">
        <tr height="40px">
            <td align="center">
                Trūkumu novēršanas priekšlikumi
                <a href="/my_page/page_suggestions_manage/2/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
        </tr>
        <tr>
            <td valign="top">
                <?php if(isset($item2)): ?>
                    <ul style="font-size: small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item2->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>