<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php echo Form::open(array('route' => ['page-canvas-strategy-multi-update', $cat, $content->id],'method'=>'POST')); ?>

    <div>
        <h4>Факторы</h4><br>
        <div class="form-group" align="left">
            <strong>Content item:</strong><br><br>
            <?php echo Form::text('content', $content->content, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Atjaunot</button>
        </div>
    </div>
    <?php echo Form::close(); ?>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>