<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" SVID analīze</strong>
                </td>
                <td>
                    <a href="/my_page/svid_efe_edit/<?php echo e($cat); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
                </td>
            </tr>
        </table>

        <br>

        <table class="table-bordered" width="800px" style="font-size: small">
            <tr>
                <td>
                    ---
                </td>
                <td align="center" height="50px" width="370px">
                    IEKŠĒJAIS SPĒKS
                </td>
                <td align="center" height="50px">
                    IEKŠĒJAIS VĀJUMS
                </td>
            </tr>
            <tr>
                <td height="200px" align="center" width="60px" style="">
                    <div style="-webkit-transform: rotate(-180deg); writing-mode:tb-rl;">ĀRĒJĀS IZDEVĪBAS</div>
                </td>
                <td align="center">
                    <div><strong>SPĒKS UN IESPĒJAS STRATĒĢIJA</strong></div><br>
                    <div>SI STRATĒĢIJA = BŪVĒT</div><br>
                    <div><strong><?php echo e($faktori_s); ?> + <?php echo e($faktori_i); ?> = <?php echo e($sektor_si); ?></strong></div>
                    <div>(fakti no 2.8. un 2.9. tabulas)</div><br>
                </td>
                <td>
                    ---
                </td>
            </tr>
            <tr>
                <td height="200px" align="center" style="">
                    <div style="-webkit-transform: rotate(-180deg); writing-mode:tb-rl;">ĀRĒJIE DRAUDI</div>
                </td>
                <td>
                    ---
                </td>
                <td>
                    ---
                </td>
            </tr>
        </table>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>