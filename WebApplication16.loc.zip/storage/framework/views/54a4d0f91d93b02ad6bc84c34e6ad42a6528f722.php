<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Alert</title>
</head>
<body>
    <div style="text-align:center; width: 100%; margin-top: 150px;">
        <img src="/images/dog.jpg" style="width: 200px">
        <p style="font-size: 9mm;">Your are <strong><?php echo e($content); ?></strong> You must be <a href="<?php echo e($link); ?>" style="color:red;">here</a></p><br>
    </div>
</body>
</html>