<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="margin-bottom: 50px;">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <table class="table-bordered" width="850px">
            <tr>
                <td width="50%" align="center">POLITISKĀ UN TIESISKĀ VIDE</td>
                <td width="50%" align="center">EKONOMISKĀ VIDE</td>
            </tr>
            <tr>
                <td style="padding:15px; vertical-align: top;">
                    <table width="100%">
                        <?php if(isset($pest_1[0])): ?>
                            <?php $__currentLoopData = $pest_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td valign="top" width="300px" style="font-size: x-small;"><div style="margin:5px;"><?php echo e($p1->text); ?></div></td>
                                <td width="15px">
                                    <a href="/my_page/pest_crud_edit/<?php echo e($cat); ?>/<?php echo e($p1->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                </td>
                                <td width="15px">
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['pest_crud_destroy', $cat, $p1->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </table>
                </td>
                <td style="padding:15px; vertical-align: top;">
                    <table width="100%">
                        <?php if(isset($pest_2[0])): ?>
                            <?php $__currentLoopData = $pest_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="300px" style="font-size: x-small;"><?php echo e($p2->text); ?></td>
                                    <td width="15px">
                                        <a href="/my_page/pest_crud_edit/<?php echo e($cat); ?>/<?php echo e($p2->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                    </td>
                                    <td width="15px">
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pest_crud_destroy', $cat, $p2->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="margin:5px; text-align: center;"><a href="/my_page/pest_crud_create/<?php echo e($cat); ?>/1" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                </td>
                <td>
                    <div style="margin:5px; text-align: center;"><a href="/my_page/pest_crud_create/<?php echo e($cat); ?>/2" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                </td>
            </tr>
        </table>

        <table class="table-bordered" width="850px" style="margin-top: 30px">
            <tr>
                <td width="50%" align="center"><div style="margin:5px;">SOCIĀLĀ UN DEMOGRĀFISKĀ VIDE</div></td>
                <td width="50%" align="center"><div style="margin:5px;">TEHNOLOĢISKĀ VIDE</div></td>
            </tr>
            <tr>
                <td style="padding:15px; vertical-align: top;">
                    <table width="100%">
                        <?php if(isset($pest_3[0])): ?>
                            <?php $__currentLoopData = $pest_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="300px" style="font-size: x-small;"><?php echo e($p3->text); ?></td>
                                    <td width="15px">
                                        <a href="/my_page/pest_crud_edit/<?php echo e($cat); ?>/<?php echo e($p3->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                    </td>
                                    <td width="15px">
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pest_crud_destroy', $cat, $p3->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </table>
                </td>
                <td style="padding:15px; vertical-align: top;">
                    <table width="100%">
                        <?php if(isset($pest_4[0])): ?>
                            <?php $__currentLoopData = $pest_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="300px" style="font-size: x-small;"><?php echo e($p4->text); ?></td>
                                    <td width="15px">
                                        <a href="/my_page/pest_crud_edit/<?php echo e($cat); ?>/<?php echo e($p4->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                    </td>
                                    <td width="15px">
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pest_crud_destroy', $cat, $p4->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="margin:5px; text-align: center;"><a href="/my_page/pest_crud_create/<?php echo e($cat); ?>/3" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                </td>
                <td>
                    <div style="margin:5px; text-align: center;"><a href="/my_page/pest_crud_create/<?php echo e($cat); ?>/4" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                </td>
            </tr>
        </table>
    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>