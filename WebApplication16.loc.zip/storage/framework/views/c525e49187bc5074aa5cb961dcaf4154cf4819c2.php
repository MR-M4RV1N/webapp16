<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div>
        <h4>Оценка</h4><br>
        <table>
            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="500px">
                    <?php echo e($c->content); ?>

                </td>
                <td>
                    <a class="btn btn-info btn-xs" href="/page_canvas/estimate_show/<?php echo e($cat); ?>/<?php echo e($c->id); ?>">Show</a>
                    <a class="btn btn-primary btn-xs" href="/page_canvas/estimate_edit/<?php echo e($cat); ?>/<?php echo e($c->id); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['page-canvas-strategy-estimate-destroy', $cat, $c->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <br><br>

        <table width="800px">
            <tr>
                <td>
                    <a class="btn btn-success btn-xs" href="<?php echo e(route('page-canvas-strategy-estimate-create', $cat)); ?>">Add</a>
                </td>
            </tr>
        </table>
    </div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>