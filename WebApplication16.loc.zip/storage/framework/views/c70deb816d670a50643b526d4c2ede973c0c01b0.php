<?php $__env->startSection('content'); ?>

    <!-- CRUD список предприятий -->
    <?php echo Form::open(array('route' => ['page-language-update'],'method'=>'POST')); ?>

    <table width="100%">
        <tr>
            <td colspan="2"><strong>Languages:</strong></td>
        </tr>
        <tr>
            <td height="10px"></td>
        </tr>

        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div style="margin-left:10px"><?php echo e($lang->name); ?></div>
                </td>
                <td>
                    <input class="form-check-input" type="radio" name="selected_language" id="<?php echo e($lang->id); ?>" value="<?php echo e($lang->name); ?>"
                       <?php if($lang->name == $selected_language ): ?>
                            checked
                       <?php endif; ?>
                    >
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <br>

    <table width="800px">
        <tr>
            <td>
                <button type="submit" class="btn btn-default" style="margin-top:10px;">Izvēlēties</button>
            </td>
        </tr>
    </table>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.home_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>