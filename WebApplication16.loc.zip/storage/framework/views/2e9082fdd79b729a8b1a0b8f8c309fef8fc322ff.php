<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <!-- Content -->
    <div align="center"> <!-- div для выравнивания по центру -->
        <table class="table table-bordered">
            <?php $__currentLoopData = $categories_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><p style="font-family:Times New Roman; margin-bottom:5px;"><span class="glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-right:10px;"></span><?php echo e($sub->name); ?></p></td>
                    <td align="center" width="90px"><button onclick="location.href='/categories_sub/edit/<?php echo e($sub->id); ?>'">Edit</button></td>
                    <td align="center" width="90px">
                        <?php echo Form::open(['method' => 'DELETE','route' => ['categories_sub_destroy', $sub->id],'style'=>'display:inline']); ?>

                        <?php echo Form::submit('Delete'); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div align="left">
            <button type="button" name="add" id="add" class="btn btn-default" onclick="location.href='/categories_sub/create/<?php echo e($cat); ?>'">Добавить</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <!-- Content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.menu_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>