<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">


        <?php echo Form::open(array('route' => ['canvas_table_crud_store', $cat, $canvas_block],'method'=>'POST')); ?>

        <div class="form-group" align="left">
            <strong>Эллемент блока...:</strong><br>
            <?php echo Form::text('item', null, array('placeholder' => 'Ievadiet tekstu', 'class' => 'form-control')); ?>

        </div>

        <div style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-sm">Saglabāt</button>
        </div>
        <?php echo Form::close(); ?>





    </div>

    <script>
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace( 'firm_description' );
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>