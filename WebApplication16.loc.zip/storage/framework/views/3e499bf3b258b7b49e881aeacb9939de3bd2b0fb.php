<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div align="center">
        <h3>PEST analīze</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>


    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" PEST analīze</strong>
                </td>
                <td>
                    <a href="/my_page/pest_edit/<?php echo e($cat); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
                </td>
            </tr>
        </table>

        <br>

        <table class="table-bordered" width="850px">
            <tr>
                <td width="50%" align="center">POLITISKĀ UN TIESISKĀ VIDE</td>
                <td width="50%" align="center">EKONOMISKĀ VIDE</td>
            </tr>
            <tr>
                <td style="vertical-align: top;">
                    <div style="margin: 10px 0px 10px 0px;">
                        <?php if(isset($pest_1[0])): ?>
                            <?php $__currentLoopData = $pest_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($p1->text); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div style="margin: 10px 0px 10px 0px;">
                        <?php if(isset($pest_2[0])): ?>
                            <?php $__currentLoopData = $pest_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($p2->text); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>

            <tr>
                <td width="50%" align="center">SOCIĀLĀ UN DEMOGRĀFISKĀ VIDE</td>
                <td width="50%" align="center">TEHNOLOĢISKĀ VIDE</td>
            </tr>
            <tr>
                <td style="vertical-align: top;">
                    <div style="margin: 10px 0px 10px 0px;">
                        <?php if(isset($pest_3[0])): ?>
                            <?php $__currentLoopData = $pest_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($p3->text); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
                <td style="vertical-align: top;">
                    <div style="margin: 10px 0px 10px 0px;">
                        <?php if(isset($pest_4[0])): ?>
                            <?php $__currentLoopData = $pest_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($p4->text); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        </table>
    </div>


    <div style="margin-top:60px; margin-left: 50px;">
        <strong>Komentārijs:</strong>
    </div>

    <div style="margin-top:10px; margin-left: 50px;">
        <?php if(isset($comment->comment)): ?>
            <?php echo html_entity_decode($comment->comment); ?>

        <?php else: ?>
            <i>Nav datu</i>
        <?php endif; ?>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>