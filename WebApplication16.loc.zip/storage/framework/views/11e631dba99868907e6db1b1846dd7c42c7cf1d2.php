<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div>
        <!-- 1/2 Trial version -->
        <p style="font-family:Times New Roman; margin-bottom:5px; margin-left:170px"><span class=" glyphicon glyphicon-folder-open" aria-hidden="true" style="margin-right:10px;"></span><?php echo e($catt[0]->name); ?></p>

        <table align="center">
            <tr>
                <td>

                    <table>
                        <?php $__currentLoopData = $check[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr height="30px">
                                <td>
                                    <?php if($ch == 1): ?>
                                        <div style="margin-left:10px">
                                            <span class="glyphicon glyphicon-check" aria-hidden="true"></span>
                                        </div>
                                    <?php else: ?>
                                        <div style="margin-left:10px">
                                            <span class="glyphicon glyphicon-unchecked" aria-hidden="true"></span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>


                </td>
                <td>

                    <table>
                        <?php $__currentLoopData = $subb_trial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr height="30px">
                                <td width="800px">

                                    <div style="font-family:Calibri Light; margin-left:10px;">
                                        <a href="/my_page/<?php echo e($s->route); ?>" style="color: #000000;"><?php echo e($s->name); ?></a>
                                    </div>

                                </td>
                                <td>
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['full-progress-map-delete', $s->id]]); ?>

                                    <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>


                </td>
            </tr>
        </table>


        <br><!-- ----------Разделитель---------- -->
        <div align="center"><button type="button" onclick="location.href='/get_pro_statuss'"><img src="/images/icons-key.png" style="width: 20px;">   Get PRO statuss</button></div>
        <br>

        <!-- 2/2 PRO version -->
        <?php $a = 1; ?>
        <?php $b = 0; ?>
        <?php for($i = 1; $i < 6; $i++): ?>
            <p style="font-family:Times New Roman; margin-bottom:5px; color: #aaaaaa; margin-left:170px"><span class=" glyphicon glyphicon-folder-open" aria-hidden="true" style="margin-right:10px;"></span><?php echo e($catt[$i]->name); ?></p>

            <table align="center">
                <tr>
                    <td>

                        <table>
                            <?php $__currentLoopData = $check[$a]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr height="30px">
                                    <td>
                                        <div style="margin-left:10px; color: #aaaaaa;">
                                            <span class="glyphicon glyphicon-lock" aria-hidden="true"></span>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>


                    </td>
                    <td>

                        <table>
                            <?php $__currentLoopData = $subb_pro[$b]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr height="30px">
                                    <td width="800px">
                                        <div style="font-family:Calibri Light; margin-left:10px;">
                                            <div style="color: #aaaaaa;"><?php echo e($s->name); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="glyphicon glyphicon-remove" style="color: #aaaaaa; margin-left:3px;"></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>


                    </td>
                </tr>
            </table>

            <br>

            <?php $a++; ?>
            <?php $b++; ?>
        <?php endfor; ?>
    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.firms_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>