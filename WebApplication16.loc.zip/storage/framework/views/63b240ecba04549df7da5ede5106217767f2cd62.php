<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" merki</strong>
                </td>
            </tr>
        </table>
        <br>

        <?php echo Form::open(array('route' => ['page-abilities-update', $cat, $id],'method'=>'POST')); ?>


        <div class="form-group" style="width:800px; text-align:left;">
            <strong>Galvenās kompetences:</strong>
            <?php echo Form::text('key_ability', $item[0]->key_ability, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" style="width:800px; text-align:left;">
            <strong>Ilgtspējība</strong>
            <?php echo Form::textarea('durability', $item[0]->durability, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" style="width:800px; text-align:left;">
            <strong>Caurredzamība</strong>
            <?php echo Form::text('transparence', $item[0]->transparence, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" style="width:800px; text-align:left;">
            <strong>Mobilitāte</strong>
            <?php echo Form::text('mobility', $item[0]->mobility, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" style="width:800px; text-align:left;">
            <strong>Neatkārtojama</strong>
            <?php echo Form::text('repeatability', $item[0]->repeatability, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>


        <div style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-sm">Atjaunot</button>
        </div>
        <?php echo Form::close(); ?>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>