<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>RUMELTA TESTS</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" attīstības stratēģijas virziens</strong>
                </td>
            </tr>
        </table>
        <br><br>


        <?php echo Form::open(array('route' => ['page-rumelt-update', $cat, $sub],'method'=>'POST')); ?>

        <table width="100%">
            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_1" value="1"
                               <?php if($select[0]['select_1'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    1. Последовательность
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_2" value="1"
                               <?php if($select[0]['select_2'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    2. Гармоничность
                </td>
            </tr>

            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_3" value="1"
                               <?php if($select[0]['select_3'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    3. Преимущество
                </td>
            </tr>


            <tr>
                <td width="50px">
                    <div class="form-check" style="margin-left:20px;">
                        <input type="checkbox" class="form-check-input" name="select_4" value="1"
                               <?php if($select[0]['select_4'] == 1): ?> checked <?php endif; ?>
                        >
                    </div>
                </td>
                <td>
                    4. Осуществимость
                </td>
            </tr>
        </table>


        <div width="850px" style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-xs">Submit</button>
        </div>
        <?php echo Form::close(); ?>



    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>