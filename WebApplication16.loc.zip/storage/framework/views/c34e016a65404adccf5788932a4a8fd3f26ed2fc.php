<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>MĒRĶI</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" merki</strong>
                </td>
                <td>
                    <a href="/my_page/strategija_merki_edit/<?php echo e($cat); ?>/<?php echo e($sub); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
                </td>
            </tr>
        </table>
        <br>

        <table width="800px" style="font-size: small;" class="table-bordered">
            <tr height="50px" align="center" style="border-bottom:3px double black">
                <td width="150px">
                    <strong>Mērķis</strong>
                </td>
                <td width="200px">
                    <strong>Paredzētās darbības mērķa izpildei</strong>
                </td>
                <td width="150px">
                    <strong>Izpildītājs</strong>
                </td>
                <td width="150px">
                    <strong>Izpildes laiks</strong>
                </td>
                <td width="150px">
                    <strong>Plānotas izmaksas</strong>
                </td>
            </tr>

            <?php if(isset($strategija_merki_result[0])): ?>
                <?php $__currentLoopData = $strategija_merki_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategija_merki_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr height="50px" style="font-size: x-small">
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->merkis); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->darbibas); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->izpilditajs); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->laiks); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->izmaksas); ?></div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr height="50px">
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>

        </table>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>