<?php $__env->startSection('content'); ?>



    <div align="center">
        <h3>Success Factors</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <table align="center" class="table-bordered" width="500px" height="50px">
        <tr>
            <td align="center">
                Veiksmei nepieciešamie nosacījumi
            </td>
        </tr>
    </table>

    <div style="text-align:center; margin:15px 0px 15px 0px;">
        <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span>
    </div>

    <table align="center" class="table-bordered" width="100%" height="300px">
        <tr height="50px">
            <td width="40%" align="center">
                <i>Ko vēlas patērētāji?</i>
            </td>
            <td width="60%" align="center">
                <i>Kā uzņēmums izdzīvo konkurences nosacījumos?</i>
            </td>
        </tr>

        <tr height="50px">
            <td align="center">
                <strong>Pieprasījuma analīze</strong>
            </td>
            <td align="center">
                <strong>Konkurences analīze</strong>
            </td>
        </tr>

        <tr>
            <td valign="top">
                <div style="margin:10px;">
                    <i>Kas ir uzņēmuma patērētāji?</i>
                    <a href="/my_page/page_success_manage/<?php echo e($cat); ?>/1/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                    <ul style="font-size: xx-small; padding-left:20px;">
                        <?php $__currentLoopData = $item1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item1->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <br>
                <div style="margin:10px;">
                    <i>Ko grib uzņēmuma patērētāji?</i>
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
            </td>
            <td valign="top">
                <div style="margin:10px;">
                    <i>Kas ir konkurences dzinējspēks?</i>
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
                <br>
                <div style="margin:10px;">
                    <i>Kādas ir konkurences pamatīpašības?</i>
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
                <br>
                <div style="margin:10px;">
                    <i>Cik intensīva ir konkurence?</i>
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
                <br>
                <div style="margin:10px;">
                    <i>Kā mēs varam panākt konkurētspējīgo priekšrocību?</i>
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
                <br>
            </td>
        </tr>
    </table>

    <div style="text-align:center; margin:15px 0px 15px 0px;">
        <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span>
    </div>

    <table align="center" class="table-bordered" width="500px" height="50px">
        <tr>
            <td align="center">
                <div>
                    Veiksmes faktori
                    <a href="" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
                </div>
            </td>
        </tr>
    </table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>