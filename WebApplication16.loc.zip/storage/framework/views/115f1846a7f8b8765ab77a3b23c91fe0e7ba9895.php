<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div align="center">
        <h3>SVID - ĀRĒJAS VIDES ANALĪZE</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" SVID analīze</strong>
                </td>
            </tr>
        </table>

        <br>

        <table class="table-bordered" width="800px">
            <tr>
                <td colspan="2" align="center">
                    ORGANIZĀCIJAS ĀRĒJĀ VIDE
                </td>
            </tr>
            <tr>
                <td align="center">
                    IESPĒJAS
                    <a href="/my_page/svid_areja_edit/<?php echo e($cat); ?>/I" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td align="center">
                    DRAUDI
                    <a href="/my_page/svid_areja_edit/<?php echo e($cat); ?>/D" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
            </tr>
            <tr>
                <td width="50%" valign="top">
                    <div style="margin: 10px;">
                        <?php if(isset($svid_1[0])): ?>
                            <?php $__currentLoopData = $svid_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($s1->item); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
                <td width="50%" valign="top">
                    <div style="margin: 10px;">
                        <?php if(isset($svid_2[0])): ?>
                            <?php $__currentLoopData = $svid_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul style="margin:0px;">
                                    <li style="font-size: x-small;"><?php echo e($s2->item); ?></li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        </table>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>