<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Life Circle</h3>
    </div>


    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>


    <?php if(@$selected_value == null): ?>
        <div align="center" style="margin-top:50px;">
            <span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span> Izvēle nav izdarīta!
        </div>

        <br><br>
    <?php endif; ?>


    <?php echo Form::open(array('route' => ['page-circle-update', $cat, $sub],'method'=>'POST')); ?>

    <table align="center" width="500px" class="table-bordered">
        <tr height="244px" align="center">
            <td style="background: url('/images/circle-1.png');" width="146px">
                <div style="margin-top:70px;">Izcelsme</div>
                <input class="form-check-input" type="radio" name="selected_value" id="selected_value" value="option1"
                       <?php if($selected_value == 'option1'): ?> checked <?php endif; ?>
                >
            </td>
            <td style="background: url('/images/circle-2.png')" width="95">
                <div style="margin-top:70px;">Izaugsme</div>
                <input class="form-check-input" type="radio" name="selected_value" id="selected_value" value="option2"
                       <?php if($selected_value == 'option2'): ?> checked <?php endif; ?>>
            </td>
            <td style="background: url('/images/circle-3.png')" width="154">
                <div style="margin-top:70px;">Briedums</div>
                <input class="form-check-input" type="radio" name="selected_value" id="selected_value" value="option3"
                       <?php if($selected_value == 'option3'): ?> checked <?php endif; ?>
                >
            </td>
            <td style="background: url('/images/circle-4.png')" width="100">
                <div style="margin-top:70px;">Kritums</div>
                <input class="form-check-input" type="radio" name="selected_value" id="selected_value" value="option4"
                       <?php if($selected_value == 'option4'): ?> checked <?php endif; ?>
                >
            </td>
        </tr>
    </table>

    <br>

    <div align="center">
        <button type="submit" class="btn btn-default btn-xs">Izvēlēties</button>
    </div>
    <?php echo Form::close(); ?>


    <?php if(@$selected_value !== null): ?>
        <?php echo Form::open(['method' => 'DELETE','route' => ['page-circle-destroy', $cat, $sub]]); ?>

            <div align="right">
                <button type="submit" class="btn btn-danger btn-xs">Delete record</button>
            </div>
        <?php echo Form::close(); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>