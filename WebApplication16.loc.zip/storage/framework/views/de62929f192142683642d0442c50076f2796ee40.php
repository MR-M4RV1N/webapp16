<?php $__env->startSection('content'); ?>

    <table width="1200px" align="center" style="margin-top:100px;">
        <tr>
            <td width="50%" align="center">
                <div style="margin-bottom:50px;">
                    <h3>WebApplication16.loc</h3>
                    <strong>Business analitic tools</strong>
                </div>
                <img src="\images\Apple-Mac-App.png" width="350px">
            </td>
            <td width="50%" align="center" valign="middle">
                <?php if(auth()->guard()->guest()): ?>
                    <?php echo $__env->make('partials.free.login1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('partials.free.you_are_logged_in', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.free_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>