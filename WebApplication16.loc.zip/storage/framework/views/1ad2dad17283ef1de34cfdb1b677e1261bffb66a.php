
<div class="panel panel-default" style="width:500px; margin-top:30px;" align="center">
    <div style="margin-top:10px; border-bottom:1px solid lightgrey;"><h3 class="panel-title" style="margin-bottom:10px;">You are logged in</h3></div>
    <div class="panel-body">

        <div class="form-group" style="margin-top:20px;">
            <button type="button" class="my-btn-sample" style="width:300px;" onclick="location.href='<?php echo e($link); ?>'">
                    <span style="color:white; font-size: small">
                        <strong>NEXT</strong> <span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span>
                    </span>
            </button>
        </div>

    </div>
</div>



