<?php $__env->startSection('content'); ?>

    <script src="<?php echo e(asset('/js/ckeditor/ckeditor.js')); ?>"
            type="text/javascript" charset="utf-8" >
    </script>

    <!-- Content -->
    <?php echo Form::open(array('route' => 'categories_store','method'=>'POST')); ?>

    <div align="center"> <!-- div для выравнивания по центру -->
        <div class="form-group">
            <strong>Название категории:</strong><br><br>
            <?php echo Form::text('name', null, array('placeholder' => 'Название категории','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
            <textarea name="category_text" cols="30" rows="5"></textarea>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->

    <script>
        CKEDITOR.replace( 'category_text' );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.menu_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>