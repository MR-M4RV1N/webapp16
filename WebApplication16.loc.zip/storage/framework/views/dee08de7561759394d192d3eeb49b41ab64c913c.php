<!--- 3 div-a для каркаса -->
<div id="page-content-wrapper">
<div class="page-content">
<div class="container-fluid">

            <!--- Белый div -->
            <div class="row" style="height:50px; line-height: 50px; padding-left: 30px; background-color: white; border-bottom:2px solid #aaaaaa;">
                <div style="font-size: 6mm"><?php echo e($page_title); ?></div>
            </div>
            <!--- / Белый div -->

<!--- 4 div-a перед контентом -->
<div class="container-fluid" style="min-height: 650px; background-color: #FBFBFB;">
<div class="row" >
<div class="col-lg-12" >
<div style="margin-top:30px; margin-bottom:30px; border:1px solid #969696; background-color: white; padding:50px 20px 50px 20px;">