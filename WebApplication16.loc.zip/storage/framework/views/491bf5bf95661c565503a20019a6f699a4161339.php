<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="margin-bottom: 50px;">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <table class="table-bordered" width="850px">
            <tr>
                <td align="center">
                    ORGANIZĀCIJAS IEKŠĒJĀ VIDE
                </td>
            </tr>
            <tr>
                <td align="center"><?php echo e($title_1); ?></td>
            </tr>
            <tr>
                <td style="padding:15px; vertical-align: top;">
                    <table width="100%">
                        <?php if(isset($svid_content[0])): ?>
                            <?php $__currentLoopData = $svid_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td valign="top" width="500px" style="font-size: small;"><div style="margin:5px;"><?php echo e($content->item); ?></div></td>
                                <td width="10px" align="center">
                                    <a href="/my_page/svid_iekseja_crud_edit/<?php echo e($cat); ?>/<?php echo e($svid_cat); ?>/<?php echo e($content->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                </td>
                                <td width="10px" align="center">
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['svid_iekseja_crud_destroy', $cat, $svid_cat, $content->id]]); ?>

                                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td>
                                    <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                                </td>
                            </tr>
                        <?php endif; ?>
                            <tr>
                                <td colspan="3">
                                    <div style="margin:5px; text-align: center;"><a href="/my_page/svid_iekseja_crud_create/<?php echo e($cat); ?>/<?php echo e($svid_cat); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                                </td>
                            </tr>
                    </table>
                </td>
            </tr>
        </table>


    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>