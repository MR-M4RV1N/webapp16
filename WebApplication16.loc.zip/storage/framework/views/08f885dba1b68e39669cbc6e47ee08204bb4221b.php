<?php $__env->startSection('content'); ?>


    <div align="center">
        <h3>VIRZIENS</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" attīstības stratēģijas virziens</strong>
                </td>
            </tr>
        </table>
        <br><br>

        <?php echo Form::open(array('route' => ['strategija_virziens_update', $cat, $sub],'method'=>'POST')); ?>

        <table width="850px" class="table-bordered">
            <tr height="50px" align="center">
                <td>
                    <strong>Intensīva (attīstības) stratēģija</strong>
                </td>
                <td>
                    <strong>Integrēta stratēģija</strong>
                </td>
                <td>
                    <strong>Diversificēta stratēģija</strong>
                </td>
                <td>
                    <strong>Samazināšanas stratēģija</strong>
                </td>
            </tr>
            <tr height="50px" align="center" style="border-top:3px double black;">
                <td>
                    Iekļūšana tirgū<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1"
                            <?php if($selected_item == 'option1'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Vertikālā integrācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2"
                           <?php if($selected_item == 'option2'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Koncentriskā diversifikācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3"
                           <?php if($selected_item == 'option3'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Konsolidācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option4"
                           <?php if($selected_item == 'option4'): ?> checked <?php endif; ?>
                    >
                </td>
            </tr>
            <tr height="50px" align="center">
                <td>
                    Tirgus daļas palielināšana<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios5" value="option5"
                           <?php if($selected_item == 'option5'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Horizontālā integrācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios6" value="option6"
                           <?php if($selected_item == 'option6'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Horizontālā diversifikācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios7" value="option7"
                           <?php if($selected_item == 'option7'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Saīsināšana<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios8" value="option8"
                           <?php if($selected_item == 'option8'): ?> checked <?php endif; ?>
                    >
                </td>
            </tr>
            <tr height="50px" align="center">
                <td>
                    Jaunas produkcijas izstrāde<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios9" value="option9"
                           <?php if($selected_item == 'option9'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>

                </td>
                <td>
                    Daudznozaru diversifikācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios10" value="option10"
                           <?php if($selected_item == 'option10'): ?> checked <?php endif; ?>
                    >
                </td>
                <td>
                    Likvidācija<br>
                    <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios11" value="option11"
                           <?php if($selected_item == 'option11'): ?> checked <?php endif; ?>
                    >
                </td>
            </tr>
        </table>
        <div width="850px" style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-xs">Submit</button>
        </div>
        <?php echo Form::close(); ?>



    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>