<div id="sidebar-wrapper" style="">
    <div style="color: #AAA7A0; height: 50px; text-align: center; padding-top:20px;">
        <p style="font-family: Palatino Linotype, Book Antiqua, Palatino, serif; font-size: medium"><strong>PRO</strong></p>
    </div>

    <div style="color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;" onclick="location.href='/page_home'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-home" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">HOME</p></span>
    </div>
    <div style="color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;" onclick="location.href='/page_profile'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-user" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">PROFILE</p></span>
    </div>
    <div style="color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;" onclick="location.href='/page_firms'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-list-alt" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">FIRMS</p></span>
    </div>
    <div style="background-color: #4A4542; color: white; height: 70px; text-align: center; cursor:pointer;"  onclick="location.href='/page_main'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-th-large" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">STRATEGY</p></span>
    </div>
    <div style="color: #AAA7A0; height: 70px; text-align: center; cursor:pointer;"  onclick="location.href='/page_models'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-th" aria-hidden="true" style="padding-top:20px;"><p style="font-size: x-small; margin-top:3px;">MODELS</p></span>
    </div>
</div>