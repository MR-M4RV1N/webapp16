<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <div class="form-group" align="left">
            <strong>Uzņēmuma nosaukums:</strong><br><br>
            <?php echo e($firm_description_result[0]->firm_name); ?>

        </div>

        <hr>

        <div class="form-group" align="left">
            <strong>Uzņēmuma apraksts:</strong><br><br>
            <?php echo $firm_description ?>
        </div>

        <div>
            <a href="/my_page/firm_description_crud_edit/<?php echo e($cat); ?>/<?php echo e($sub); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
        </div>

    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>