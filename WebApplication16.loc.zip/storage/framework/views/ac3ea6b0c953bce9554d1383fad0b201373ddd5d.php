<?php $__env->startSection('content'); ?>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3><?php echo e($title); ?></h3>
    </div>

    <br><br>

    <table style="border:1px solid lightgrey" width="700px" align="center">
        <tr height="50px">
            <td colspan="4" style="border-bottom:1px solid lightgrey">
                <div style="margin-left:20px;">
                    <?php if(isset($table_title)): ?>
                        <i><?php echo e($table_title); ?></i>
                    <?php else: ?>
                        <i>Izvēlēta bloka elementi:</i>
                    <?php endif; ?>
                </div>
            </td>
        </tr>

        <tr>
            <td colspan="4" height="10px">

            </td>
        </tr>

        <?php if(isset($item[0])): ?>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr height="30px">
                    <td width="50px" align="right">
                        <?php echo e($i); ?>.
                    </td>
                    <td>
                        <div style="margin-left:10px;">
                            <?php echo e($item->item); ?>

                        </div>
                    </td>
                    <td width="40px" align="center">
                        <a href="/my_page/page_resources_edit/<?php echo e($cat); ?>/<?php echo e($item->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                    </td>
                    <td width="40px" align="left">
                        <?php echo Form::open(['method' => 'DELETE','route' => ['page-resources-destroy', $cat, $category, $item->id]]); ?>

                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="4" height="30px">
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
            </tr>
        <?php endif; ?>

        <tr>
            <td colspan="4" height="10px">

            </td>
        </tr>

    </table>

    <div style="margin:30px 0px 10px 0px; text-align: center;">
        <a href="/my_page/page_resources_create/<?php echo e($cat); ?>/<?php echo e($category); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>