<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Resources</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <?php echo e($table_models_text->text); ?>

        <?php endif; ?>
    </div>

    <table class="table-bordered" width="100%" height="400px">
        <tr>
            <td rowspan="2" width="20%">Материальные</td>
            <td width="20%" style="border-right:1px solid white;">
                Финансовые ресурсы
            </td>
            <td width="10%" align="center">
                <a href="/my_page/page_resources_manage/1/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td width="50%" valign="top">
                <?php if(isset($item1)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item1->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td style="border-right:1px solid white;">
                Физические ресурсы
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/2/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item2)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item2->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td rowspan="2">Неатериальные ресурсы</td>
            <td style="border-right:1px solid white;">
                Технологические ресурсы
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/3/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item3)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item3->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td style="border-right:1px solid white;">
                Репутация
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/4/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item4)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item4->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td rowspan="3">Человеческие ресурсы</td>
            <td style="border-right:1px solid white;">
                Навыки и знания
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/5/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item5)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item5->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td style="border-right:1px solid white;">
                Способность к взаимодействию
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/6/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item6)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item6->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td style="border-right:1px solid white;">
                Мотивация
            </td>
            <td align="center">
                <a href="/my_page/page_resources_manage/7/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> edit</a>
            </td>
            <td valign="top">
                <?php if(isset($item7)): ?>
                    <ul style="font-size: x-small; padding-left:30px; padding-top:10px;">
                        <?php $__currentLoopData = $item7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item7->item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </td>
        </tr>
    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>