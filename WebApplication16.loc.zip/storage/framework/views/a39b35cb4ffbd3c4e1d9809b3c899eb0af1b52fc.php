<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->
    <div align="center" style="margin-top:150px">
        <div style="font-size: large">
            <strong><p>Business Analitic Tools</p></strong>
        </div>
        <hr style="border: 1px solid black">
        <div>
            <img width="100" src="/images/remont.png">
        </div>
    </div>


</div>