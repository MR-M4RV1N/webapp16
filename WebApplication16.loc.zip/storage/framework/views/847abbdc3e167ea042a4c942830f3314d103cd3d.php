<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" merki</strong>
                </td>
            </tr>
        </table>
        <br>

        <table width="850px" style="font-size: small;" class="table-bordered">
            <tr height="50px" align="center" style="border-bottom:3px double black">
                <td width="150px">
                    <strong>Mērķis</strong>
                </td>
                <td width="200px">
                    <strong>Paredzētās darbības mērķa izpildei</strong>
                </td>
                <td width="150px">
                    <strong>Izpildītājs</strong>
                </td>
                <td width="150px">
                    <strong>Izpildes laiks</strong>
                </td>
                <td width="150px">
                    <strong>Plānotas izmaksas</strong>
                </td>
                <td width="50px" colspan="2">
                    ACTIONS
                </td>
            </tr>

            <?php if(isset($strategija_merki_result[0])): ?>
                <?php $__currentLoopData = $strategija_merki_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strategija_merki_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr height="50px" style="font-size: x-small">
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->merkis); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->darbibas); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->izpilditajs); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->laiks); ?></div>
                        </td>
                        <td>
                            <div style="margin-left:5px;"><?php echo e($strategija_merki_result->izmaksas); ?></div>
                        </td>
                        <td width="25" align="center">
                            <a href="/my_page/strategija_merki_crud_edit/<?php echo e($cat); ?>/<?php echo e($sub); ?>/<?php echo e($strategija_merki_result->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </td>
                        <td width="25" align="center">
                            <?php echo Form::open(['method' => 'DELETE','route' => ['strategija_merki_destroy', $cat, $sub, $strategija_merki_result->id]]); ?>

                            <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr height="50px">
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                    <td>
                        <div style="margin-left:30px;">
                            <i>...</i>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>

        </table>


        <div style="margin:30px 0px 10px 0px; text-align: center;">
            <a href="/my_page/strategija_merki_crud_create/<?php echo e($cat); ?>/<?php echo e($sub); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a>
        </div>

    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>