<!--- 3 div-a для каркаса -->
<div id="page-content-wrapper">
<div class="page-content">
<div class="container-fluid">
    <!--- Белый div -->
    <div class="row" style="height:50px; line-height: 50px; padding-left: 30px; background-color: white; border-bottom:2px solid #aaaaaa;">
        <div style="font-size: 6mm; float: left;"><?php echo e($page_title); ?></div>


        <!-- Right Side Of Navbar -->
        <ul class="nav navbar-nav navbar-right" style="margin-right:30px;">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu">
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- -->
    </div>
    <!--- / Белый div -->
</div>

<!--- 1 из 4 div перед контентом -->
<div style="min-height: 650px; padding-bottom:0px; background-color: #FBFBFB;">

<!-- Хлебные крошки -->
<div class="row" style="margin:0px;">
    <div class="col-lg-12">

        <div style="margin-top:10px;">
            <div class="btn-group" role="group" style="float:left; margin-left:10px;">
                <button type="button" class="btn btn-sm" style="background-color:white; border: 1px solid grey">
                    <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
                </button>
                <button type="button" class="btn btn-sm" style="background-color:white; border: 1px solid grey">
                    <span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span>
                </button>
            </div>
            <div class="btn-group" role="group" style="float:left; margin-left:10px;">
                <button type="button" class="btn btn-sm" style="background-color:white; border: 1px solid grey">
                    <span class="glyphicon glyphicon-retweet" aria-hidden="true"></span>
                </button>
            </div>
            <ul class="my_breadcrumb">
                <span class="
                    <?php if($page_sidebar == 'home'): ?> glyphicon glyphicon-home <?php endif; ?>
                    <?php if($page_sidebar == 'strategy'): ?> glyphicon glyphicon-th-large <?php endif; ?>
                    <?php if($page_sidebar == 'models'): ?> glyphicon glyphicon-th <?php endif; ?>
                    <?php if($page_sidebar == 'stratagems'): ?> glyphicon glyphicon-knight <?php endif; ?>
                    <?php if($page_sidebar == 'theories'): ?> glyphicon glyphicon-book <?php endif; ?>
                " aria-hidden="true"></span>

                <?php if(isset($page_breadcrumbs)): ?>
                    <?php $__currentLoopData = $page_breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_name => $p_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($p_link); ?>"><strong><?php echo e($p_name); ?></strong></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <li><?php echo e($page_title); ?></li>
            </ul>
        </div>

    </div>
</div>
<!-- / Хлебные крошки -->


<!--- 2 из 4 div перед контентом -->
<div class="row" style="margin:0px;">