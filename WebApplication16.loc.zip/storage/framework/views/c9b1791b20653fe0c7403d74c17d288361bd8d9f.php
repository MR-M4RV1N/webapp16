<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" canvas business model</strong>
                </td>
            </tr>
        </table>
        <br><br>


        <table width="850px" class="canvas-table">
            <tr align="center">
                <td rowspan="2" width="170">
                    <img src="/images/Canvas/kp.png" ><br>
                    <?php echo e($firm_canvas_kp_result); ?><br>
                    Galvenie partneri<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/kp" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td height="170px" width="170">
                    <img src="/images/Canvas/kd.png" ><br>
                    <?php echo e($firm_canvas_kd_result); ?><br>
                    Galvenās aktivitātes<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/kd" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td colspan="2" rowspan="2" width="85">
                    <img src="/images/Canvas/cp.png" ><br>
                    <?php echo e($firm_canvas_cp_result); ?><br>
                    Vērtigie piedavājumi<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/cp" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td height="170px" width="170">
                    <img src="/images/Canvas/vk.png" ><br>
                    <?php echo e($firm_canvas_vk_result); ?><br>
                    Attiecības ar klientiem<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/vk" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td rowspan="2" width="170">
                    <img src="/images/Canvas/ps.png" ><br>
                    <?php echo e($firm_canvas_ps_result); ?><br>
                    Pateretāju segmenti<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/ps" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
            </tr>
            <tr align="center">
                <td height="170px">
                    <img src="/images/Canvas/kr.png" ><br>
                    <?php echo e($firm_canvas_kr_result); ?><br>
                    Galvenie resursi<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/kr" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td height="170px">
                    <img src="/images/Canvas/ks.png" ><br>
                    <?php echo e($firm_canvas_ks_result); ?><br>
                    Noietas kanali<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/ks" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
            </tr>
            <tr height="150px" align="center">
                <td colspan="3">
                    <img src="/images/Canvas/si.png" ><br>
                    <?php echo e($firm_canvas_si_result); ?><br>
                    Izdevumu struktūra<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/si" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
                <td colspan="3">
                    <img src="/images/Canvas/pd.png" ><br>
                    <?php echo e($firm_canvas_pd_result); ?><br>
                    Ienākumu struktūra<br>
                    <a href="/page_canvas/canvas_table_edit/<?php echo e($cat); ?>/pd" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                </td>
            </tr>
        </table>

    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>