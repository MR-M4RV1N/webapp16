<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <div>
        <strong>Основные инструменты:</strong><br>
        <div style="margin-left:10px;">
            <?php $__currentLoopData = $subb_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($s->name); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <br>

        <strong>Дополнительные инструменты:</strong><br>
        <div style="margin-left:10px;">
            <?php $__currentLoopData = $subb_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($s->name); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.models_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>