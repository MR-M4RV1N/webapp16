<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="margin-bottom: 50px;">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <table class="table-bordered" width="800px" style="font-size: small">
            <tr>
                <td align="center" width="50px">
                    N. p. k.
                </td>
                <td align="center" width="300px">
                    Darbības kritērijs
                </td>
                <td align="center" width="90px">
                    Nozīmīguma līmenis:<br>
                    1–nozīmīgs,<br>
                    2-ļoti nozīmīgs,<br>
                    3-izšķiroša nozīme
                </td>
                <td align="center" width="90px">
                    Attiecīgā faktora pašreizējā ietekme uz organizāciju
                </td>
                <td align="center" width="90px">
                    Vēlamais vērtējums pēc 4 gadiem
                </td>
                <td align="center" width="90px">
                    Kopējais esošais vērtējums
                </td>
                <td align="center" width="90px">
                    Kopējais vēlamais vērtējums
                </td>
                <td colspan="2">
                    ACTIONS
                </td>
            </tr>
            <tr style="border-top: 1px double grey;">
                <td colspan="9"></td>
            </tr>


            <?php if(isset($svid_efe_i[0])): ?>
                <?php $__currentLoopData = $svid_efe_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efe_i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center">-</td>
                        <td><?php echo e($efe_i->darbibas_kriterijs); ?> (<?php echo e($efe_i->category); ?>)</td>
                        <td align="center"><?php echo e($efe_i->nozimiguma_limenis); ?></td>
                        <td align="center"><?php echo e($efe_i->faktora_pasreizeja_ietekme); ?></td>
                        <td align="center"><?php echo e($efe_i->velamais_vertejums_pec_4_gadiem); ?></td>
                        <td align="center"><?php echo e($efe_i->kopejais_esosais_vertejums); ?></td>
                        <td align="center"><?php echo e($efe_i->kopejais_velamais_vertejums); ?></td>
                        <td align="center">
                            <a href="/my_page/svid_efe_crud_edit/<?php echo e($cat); ?>/<?php echo e($efe_i->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </td>
                        <td align="center">
                            <?php echo Form::open(['method' => 'DELETE','route' => ['svid_efe_crud_destroy', $cat, $efe_i->id]]); ?>

                            <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="9">
                        <div style="margin:5px; text-align: center;"><a href="/my_page/svid_efe_crud_create/<?php echo e($cat); ?>/i" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        edit
                    </td>
                    <td>
                        delete
                    </td>
                </tr>
            <?php endif; ?>

            <?php if(isset($svid_efe_d[0])): ?>
                <tr style="border-top: 1px double grey;">
                    <td colspan="9"></td>
                </tr>
                <?php $__currentLoopData = $svid_efe_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $efe_d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center">-</td>
                        <td><?php echo e($efe_d->darbibas_kriterijs); ?> (<?php echo e($efe_d->category); ?>)</td>
                        <td align="center"><?php echo e($efe_d->nozimiguma_limenis); ?></td>
                        <td align="center"><?php echo e($efe_d->faktora_pasreizeja_ietekme); ?></td>
                        <td align="center"><?php echo e($efe_d->velamais_vertejums_pec_4_gadiem); ?></td>
                        <td align="center"><?php echo e($efe_d->kopejais_esosais_vertejums); ?></td>
                        <td align="center"><?php echo e($efe_d->kopejais_velamais_vertejums); ?>

                        <td align="center">
                            <a href="/my_page/svid_efe_crud_edit/<?php echo e($cat); ?>/<?php echo e($efe_d->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </td>
                        <td align="center">
                            <?php echo Form::open(['method' => 'DELETE','route' => ['svid_efe_crud_destroy', $cat, $efe_d->id]]); ?>

                            <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="9">
                        <div style="margin:5px; text-align: center;"><a href="/my_page/svid_efe_crud_create/<?php echo e($cat); ?>/d" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        edit
                    </td>
                    <td>
                        delete
                    </td>
                </tr>
            <?php endif; ?>
            <tr style="border-top: 1px double grey;">
                <td colspan="9"></td>
            </tr>

            <tr>
                <td colspan="2" align="center">KOPĀ:</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="5" align="center">VIDĒJĀ SVĒRTĀ ATZĪME:</td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
        </table>


    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>