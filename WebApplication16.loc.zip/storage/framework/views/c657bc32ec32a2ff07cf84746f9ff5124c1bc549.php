<?php $__env->startSection('content'); ?>


    <div align="center">


        <?php echo Form::open(array('route' => ['firm-description-crud-update', $cat, $sub],'method'=>'POST')); ?>

        <div class="form-group" align="left">
            <strong>Uzņēmuma nosaukums:</strong><br>
            <?php echo Form::text('firm_name', $firm_description_result[0]->name, array('placeholder' => 'Ievadiet tekstu', 'class' => 'form-control')); ?>

        </div>

        <div class="form-group" align="left">
            <strong>Uzņēmuma apraksts:</strong><br>
            <?php echo Form::textarea('firm_description', $firm_description_result[0]->description, array('name'=>'firm_description','id'=>'firm_description')); ?>

        </div>

        <div style="margin-top:30px;">
            <button type="submit" class="btn btn-default btn-sm">Atjaunot</button>
        </div>
        <?php echo Form::close(); ?>





    </div>

    <script>
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace( 'firm_description' );
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>