<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <table>
            <tr>
                <td>
                    <strong>Uzņēmuma "X" SVID analīze</strong>
                </td>
                <td>
                    <a href="/my_page/svid_ife_edit/<?php echo e($cat); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
                </td>
            </tr>
        </table>

        <br>

        <table class="table-bordered" width="800px" style="font-size: small">
            <tr>
                <td align="center" width="50px">
                    N. p. k.
                </td>
                <td align="center" width="300px">
                    Darbības kritērijs
                </td>
                <td align="center" width="90px">
                    Nozīmīguma līmenis:<br>
                    1–nozīmīgs,<br>
                    2-ļoti nozīmīgs,<br>
                    3-izšķiroša nozīme
                </td>
                <td align="center" width="90px">
                    Vērtējums salīdzinājumā ar konkurentiem
                </td>
                <td align="center" width="90px">
                    Vēlamais vērtējums pēc 4 gadiem
                </td>
                <td align="center" width="90px">
                    Kopējais esošais vērtējums
                </td>
                <td align="center" width="90px">
                    Kopējais vēlamais vērtējums
                </td>
            </tr>


                <?php if(isset($svid_ife_s[0])): ?>
                    <?php $__currentLoopData = $svid_ife_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ife_s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center">-</td>
                            <td><?php echo e($ife_s->darbibas_kriterijs); ?> (<?php echo e($ife_s->category); ?>)</td>
                            <td align="center"><?php echo e($ife_s->nozimiguma_limenis); ?></td>
                            <td align="center"><?php echo e($ife_s->vertejums_salidzinijuma_ar_konkurentiem); ?></td>
                            <td align="center"><?php echo e($ife_s->velamais_vertejums_pec_4_gadiem); ?></td>
                            <td align="center"><?php echo e($ife_s->kopejais_esosais_vertejums); ?></td>
                            <td align="center"><?php echo e($ife_s->kopejais_velamais_vertejums); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                <?php endif; ?>

                <?php if(isset($svid_ife_v[0])): ?>
                    <tr style="border-top: 1px double grey;">
                        <td colspan="7"></td>
                    </tr>
                    <?php $__currentLoopData = $svid_ife_v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ife_v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center">-</td>
                            <td><?php echo e($ife_v->darbibas_kriterijs); ?> (<?php echo e($ife_v->category); ?>)</td>
                            <td align="center"><?php echo e($ife_v->nozimiguma_limenis); ?></td>
                            <td align="center"><?php echo e($ife_v->vertejums_salidzinijuma_ar_konkurentiem); ?></td>
                            <td align="center"><?php echo e($ife_v->velamais_vertejums_pec_4_gadiem); ?></td>
                            <td align="center"><?php echo e($ife_v->kopejais_esosais_vertejums); ?></td>
                            <td align="center"><?php echo e($ife_v->kopejais_velamais_vertejums); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                <?php endif; ?>


            <tr>
                <td colspan="2" align="center">KOPĀ:</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="5" align="center">VIDĒJĀ SVĒRTĀ ATZĪME:</td>
                <td></td>
                <td></td>
            </tr>
        </table>


    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>