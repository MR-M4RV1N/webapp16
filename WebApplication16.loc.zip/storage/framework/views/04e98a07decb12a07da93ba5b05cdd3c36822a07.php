<?php $__env->startSection('content'); ?>

    <div align="center" style="margin-bottom: 30px;">
        <h3>Uzņēmuma apraksts</h3>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <?php if(isset($firm_description_result[0]->name) and isset($firm_description_result[0]->description)): ?>
        <div align="center">

            <div class="form-group" align="left">
                <strong>Uzņēmuma nosaukums:</strong><br><br>
                <?php echo e($firm_description_result[0]->name); ?>

            </div>

            <hr>

            <div class="form-group" align="left">
                <strong>Uzņēmuma apraksts:</strong><br><br>
                <?php echo $firm_description_result[0]->description ?> <!-- Эта строчка нужна для корректного отображения html тегов -->
            </div>

            <div>
                <a href="/my_page/firm_description_crud_edit/<?php echo e($cat); ?>/<?php echo e($sub); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
            </div>

        </div>
    <?php else: ?>
        <div align="center">
            <div class="form-group" align="left">
                <strong>Uzņēmuma nosaukums:</strong><br><br>
                <i>Nav datu</i>
            </div>

            <hr>

            <div class="form-group" align="left">
                <strong>Uzņēmuma apraksts:</strong><br><br>
                <i>Nav datu</i>
            </div>

            <div>
                <a href="/my_page/page_description_first_create/<?php echo e($cat); ?>/<?php echo e($sub); ?>" class="btn btn-default btn-xs" style="margin-left:15px;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="margin-right:5px;"></span>EDIT</a>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>