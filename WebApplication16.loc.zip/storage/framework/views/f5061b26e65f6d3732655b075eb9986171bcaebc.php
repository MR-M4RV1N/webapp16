<?php $__env->startSection('content'); ?>
    
    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
    <div align="center">
        <h3><?php echo e($page_title); ?></h3>
    </div>
    
    <br><br>


    <table class="table-bordered" width="100%">
        <tr align="center" height="50px">
            <td>Galvenās kompetences</td>
            <td>Ilgtspējība</td>
            <td>Caurredzamība</td>
            <td>Mobilitāte</td>
            <td>Neatkārtojama</td>
            <?php if(isset($item[0])): ?>
                <td colspan="2"><i>ACTIONS</i></td>
            <?php endif; ?>
        </tr>

        <?php if(isset($item[0])): ?>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr height="50px" style="font-size: x-small">
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->key_ability); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->durability); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->transparence); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->mobility); ?></div>
                    </td>
                    <td>
                        <div style="margin-left:5px;"><?php echo e($item->repeatability); ?></div>
                    </td>
                    <td width="40px" align="center">
                        <a href="/my_page/page_abilities_edit/<?php echo e($cat); ?>/<?php echo e($item->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                    </td>
                    <td width="40px" align="center">
                        <?php echo Form::open(['method' => 'DELETE','route' => ['page-abilities-destroy', $cat, $item->id]]); ?>

                        <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr height="50px" style="font-size: x-small">
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
                <td>
                    <div style="margin-left:30px;">
                        <i>...</i>
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </table>

    <div style="margin:30px 0px 10px 0px; text-align: center;">
        <a href="/my_page/page_abilities_create/<?php echo e($cat); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>