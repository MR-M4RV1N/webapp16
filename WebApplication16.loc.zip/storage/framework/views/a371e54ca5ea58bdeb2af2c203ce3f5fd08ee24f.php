<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="margin-bottom: 50px;">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <table class="table-bordered" width="800px" style="font-size: small">
            <tr>
                <td align="center" width="50px">
                    N. p. k.
                </td>
                <td align="center" width="300px">
                    Darbības kritērijs
                </td>
                <td align="center" width="90px">
                    Nozīmīguma līmenis:<br>
                    1–nozīmīgs,<br>
                    2-ļoti nozīmīgs,<br>
                    3-izšķiroša nozīme
                </td>
                <td align="center" width="90px">
                    Vērtējums salīdzinājumā ar konkurentiem
                </td>
                <td align="center" width="90px">
                    Vēlamais vērtējums pēc 4 gadiem
                </td>
                <td align="center" width="90px">
                    Kopējais esošais vērtējums
                </td>
                <td align="center" width="90px">
                    Kopējais vēlamais vērtējums
                </td>
                <td colspan="2">
                    ACTIONS
                </td>
            </tr>
            <tr style="border-top: 1px double grey;">
                <td colspan="9"></td>
            </tr>


            <?php if(isset($svid_ife_s[0])): ?>
                <?php $__currentLoopData = $svid_ife_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ife_s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center">-</td>
                        <td><?php echo e($ife_s->darbibas_kriterijs); ?> (<?php echo e($ife_s->category); ?>)</td>
                        <td align="center"><?php echo e($ife_s->nozimiguma_limenis); ?></td>
                        <td align="center"><?php echo e($ife_s->vertejums_salidzinijuma_ar_konkurentiem); ?></td>
                        <td align="center"><?php echo e($ife_s->velamais_vertejums_pec_4_gadiem); ?></td>
                        <td align="center"><?php echo e($ife_s->kopejais_esosais_vertejums); ?></td>
                        <td align="center"><?php echo e($ife_s->kopejais_velamais_vertejums); ?></td>
                        <td align="center">
                            <a href="/my_page/svid_ife_crud_edit/<?php echo e($cat); ?>/<?php echo e($ife_s->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </td>
                        <td align="center">
                            <?php echo Form::open(['method' => 'DELETE','route' => ['svid_ife_crud_destroy', $cat, $ife_s->id]]); ?>

                                <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="9">
                            <div style="margin:5px; text-align: center;"><a href="/my_page/svid_ife_crud_create/<?php echo e($cat); ?>/s" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                        </td>
                    </tr>
            <?php else: ?>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        edit
                    </td>
                    <td>
                        delete
                    </td>
                </tr>
            <?php endif; ?>

            <?php if(isset($svid_ife_v[0])): ?>
                <tr style="border-top: 1px double grey;">
                    <td colspan="9"></td>
                </tr>
                <?php $__currentLoopData = $svid_ife_v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ife_v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center">-</td>
                        <td><?php echo e($ife_v->darbibas_kriterijs); ?> (<?php echo e($ife_v->category); ?>)</td>
                        <td align="center"><?php echo e($ife_v->nozimiguma_limenis); ?></td>
                        <td align="center"><?php echo e($ife_v->vertejums_salidzinijuma_ar_konkurentiem); ?></td>
                        <td align="center"><?php echo e($ife_v->velamais_vertejums_pec_4_gadiem); ?></td>
                        <td align="center"><?php echo e($ife_v->kopejais_esosais_vertejums); ?></td>
                        <td align="center"><?php echo e($ife_v->kopejais_velamais_vertejums); ?>

                        <td align="center">
                            <a href="/my_page/svid_ife_crud_edit/<?php echo e($cat); ?>/<?php echo e($ife_v->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                        </td>
                        <td align="center">
                            <?php echo Form::open(['method' => 'DELETE','route' => ['svid_ife_crud_destroy', $cat, $ife_v->id]]); ?>

                                <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="9">
                        <div style="margin:5px; text-align: center;"><a href="/my_page/svid_ife_crud_create/<?php echo e($cat); ?>/v" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>
                        edit
                    </td>
                    <td>
                        delete
                    </td>
                </tr>
            <?php endif; ?>
            <tr style="border-top: 1px double grey;">
                <td colspan="9"></td>
            </tr>

            <tr>
                <td colspan="2" align="center">KOPĀ:</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="5" align="center">VIDĒJĀ SVĒRTĀ ATZĪME:</td>
                <td></td>
                <td></td>
                <td colspan="2"></td>
            </tr>
        </table>


    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>