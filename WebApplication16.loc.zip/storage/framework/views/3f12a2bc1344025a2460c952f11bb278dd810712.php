<?php $__env->startSection('content'); ?>



    <script src="<?php echo e(asset('/js/tinymce/tinymce.min.js')); ?>"
            type="text/javascript" charset="utf-8" >
    </script>



    <!-- Content -->
    <?php echo Form::open(array('route' => ['page-stratagems-update', $item->id],'method'=>'POST', 'enctype'=>'multipart/form-data')); ?>

    <div align="left" style="margin-left:30px;"> <!-- div для выравнивания по центру -->
        <div class="form-group" style="width:800px;">
            <strong>Номер стратагемы:</strong>
            <?php echo Form::number('number', $item->number);; ?>

        </div>

    </div>

    <hr>

    <div align="left" style="margin-left:30px;"> <!-- div для выравнивания по центру -->

        <div class="form-group">
            <strong>Название:</strong>
            <?php echo Form::text('title', $item->title, array('placeholder' => 'Введите текст','class' => 'form-control')); ?>

        </div>

        <div>
            <strong>Введение:</strong>
            <?php echo Form::textarea('intro', $item->intro, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>Описание:</strong>
            <?php echo Form::textarea('description', $item->description, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>Ключевые элементы:</strong>
            <?php echo Form::textarea('key_elements', $item->key_elements, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <br><br>

        <div class="form-group">
            <strong>Схема:</strong>
            <?php if(isset($item->schema)): ?>
                <br><br>

                <table>
                    <tr>
                        <td>
                            <img src="/images/Stratagems/<?php echo e($item->schema); ?>" width="100px">
                            <?php echo e(Form::hidden('old_schema', $item->schema)); ?>

                        </td>
                        <td width="30px">

                        </td>
                        <td>
                            <?php echo Form::file('schema');; ?>

                        </td>
                    </tr>
                </table>

            <?php else: ?>
                <?php echo Form::file('schema');; ?>

            <?php endif; ?>
        </div>

        <br><br>

        <div>
            <strong>Особенности:</strong>
            <?php echo Form::textarea('features', $item->features, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>Бизнес:</strong>
            <?php echo Form::textarea('business', $item->business, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>История:</strong>
            <?php echo Form::textarea('history', $item->history, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <br><br>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-default btn-sm">SAVE</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->

    <script type="text/javascript">
        tinymce.init({
            selector: '.myeditablediv',
            plugins: "lists image",

        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>