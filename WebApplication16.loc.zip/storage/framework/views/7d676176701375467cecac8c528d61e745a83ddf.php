<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="margin-bottom: 50px;">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <table class="table-bordered" width="850px">
            <tr>
                <td>

                </td>
                <td align="center">
                    <?php echo e($title_1); ?>

                </td>
            </tr>
            <tr>
                <td align="center">
                    <div style="-webkit-transform: rotate(-180deg); writing-mode:tb-rl;"><?php echo e($title_3); ?></div>
                </td>
                <td>
                    <table width="100%">
                        <tr style="border-bottom: 1px dashed #cfcfcf">
                            <td align="center" colspan="3">
                                <?php echo e($title_2); ?>

                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" height="10px"></td>
                        </tr>
                        <?php if(isset($strategy_result[0])): ?>
                            <?php $__currentLoopData = $strategy_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <ul style="margin:0px;">
                                            <li><?php echo e($r->strategy); ?></li>
                                        </ul>
                                    </td>
                                    <td width="30px">
                                        <a href="/my_page/svid_tows_crud_edit/<?php echo e($cat); ?>/<?php echo e($strategy_cat); ?>/<?php echo e($r->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                    </td>
                                    <td width="30px">
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['svid_tows_crud_destroy', $cat, $strategy_cat, $r->id]]); ?>

                                            <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">
                                    <div style="margin:30px 30px 100px 30px; font-size: x-small;">...</div>
                                </td>
                            </tr>
                        <?php endif; ?>
                            <tr>
                                <td align="center" colspan="3">
                                    <div style="margin:5px 0px 10px 0px; text-align: center;"><a href="/my_page/svid_tows_crud_create/<?php echo e($cat); ?>/<?php echo e($strategy_cat); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
                                </td>
                            </tr>
                    </table>
                </td>
            </tr>
        </table>



    </div>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>