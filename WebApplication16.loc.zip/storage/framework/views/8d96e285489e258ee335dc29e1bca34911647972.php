<?php $__env->startSection('content'); ?>

    <p><?php echo e($content); ?></p>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>