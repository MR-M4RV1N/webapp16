<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <?php echo Form::open(array('route' => ['svid_efe_crud_store', $cat, $svid_efe_category],'method'=>'POST')); ?>

    <div align="left"> <!-- div для выравнивания по центру -->
        <div class="form-group" align="left">
            <strong>Elements:</strong>
            <?php echo Form::text('darbibas_kriterijs', null, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>

        <hr>

        <div class="form-group">
            <strong>Nozimīguma līmenis:</strong>
            <?php echo Form::select('nozimiguma_limenis', array('1' => '1–nozīmīgs', '2' => '2-ļoti nozīmīgs', '3' => '3-izšķiroša nozīme'), null, ['class' => 'form-control']);; ?>

        </div>

        <div class="form-group">
            <strong>Attiecīgā faktora pašreizējā ietekme uz organizāciju:</strong>
            <?php echo Form::number('faktora_pasreizeja_ietekme', null, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Velamais vertējums pēc 4 gadiem:</strong>
            <?php echo Form::number('velamais_vertejums_pec_4_gadiem', null, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Kopejais ēsošais vertējums:</strong>
            <?php echo Form::number('kopejais_esosais_vertejums', null, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>

        <div class="form-group">
            <strong>Kopejais vēlamais vertējums:</strong>
            <?php echo Form::number('kopejais_velamais_vertejums', null, array('class' => 'form-control', 'placeholder' => '1-10', 'maxlength' => 10)); ?>

        </div>


        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Saglabāt</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>