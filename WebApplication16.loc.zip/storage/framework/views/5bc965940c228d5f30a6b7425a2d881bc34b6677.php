<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->
    <table width="100%" height="50px" align="center">
        <tr>
            <td align="center">
                <strong><p style="color: white;">Business Analitic Tools</p></strong>
            </td>
        </tr>
    </table>

    <hr style="margin:0px 20px 20px 20px;">


</div>