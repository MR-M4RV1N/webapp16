<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <?php echo Form::open(array('route' => ['page-success-crud-store', $cat, $category],'method'=>'POST')); ?>

    <div align="center"> <!-- div для выравнивания по центру -->
        <div class="form-group">
            <strong>Новый пункт:</strong><br><br>
            <?php echo Form::text('item', null, array('placeholder' => 'Введите текст','class' => 'form-control')); ?>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>