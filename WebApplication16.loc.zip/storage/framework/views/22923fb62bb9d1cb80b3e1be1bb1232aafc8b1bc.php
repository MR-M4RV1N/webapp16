<div id="sidebar-wrapper" style="border:1px solid black;">
    <div style="margin-top:50px; border-top:1px solid white; border-bottom:1px solid white; background-color: black; height: 50px; line-height: 50px; text-align:center; color: white;">
        <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
    </div>
    <div style="border-bottom:1px solid white; height: 50px; line-height: 50px; color: white; text-align: center; cursor:pointer;"  onclick="location.href='/page_main'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
        <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
    </div>
    <div style="border-bottom:1px solid white; height: 50px; line-height: 50px; color: white; text-align: center;">
        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
    </div>
    <div style="border-bottom:1px solid white; height: 50px; line-height: 50px; color: white; text-align: center;">
        <span class="glyphicon glyphicon-hdd" aria-hidden="true"></span>
    </div>
    <div style="border-bottom:1px solid white; height: 50px; line-height: 50px; color: white; text-align: center;">
        <span class="glyphicon glyphicon-tasks" aria-hidden="true"></span>
    </div>
</div>