<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php echo Form::open(array('route' => ['page-canvas-strategy-ocean-store', $cat],'method'=>'POST')); ?>

    <div>
        <h4>Голубой океан</h4><br>
        <div class="form-group" align="left">
            <strong>Content item:</strong><br><br>
            <?php echo Form::text('content', null, array('placeholder' => 'Введите текст', 'class' => 'form-control')); ?>

        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Pievienot</button>
        </div>
    </div>
    <?php echo Form::close(); ?>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.canvas_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>