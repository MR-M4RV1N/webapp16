<?php $__env->startSection('content'); ?>

    <script src="<?php echo e(asset('/js/tinymce/tinymce.min.js')); ?>"
            type="text/javascript" charset="utf-8" >
    </script>


    <!-- Content -->
    <?php echo Form::open(array('route' => ['page-theories-store'],'method'=>'POST', 'enctype'=>'multipart/form-data')); ?>

    <div align="left" style="margin-left:30px;"> <!-- div для выравнивания по центру -->

        <div class="form-group">
            <strong>Название:</strong>
            <?php echo Form::text('title', null, array('placeholder' => 'Введите текст','class' => 'form-control')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>Описание:</strong>
            <?php echo Form::textarea('description', null, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <div style="margin-top:50px;">
            <strong>Текст:</strong>
            <?php echo Form::textarea('text', null, array('placeholder' => 'Введите текст','class' => 'myeditablediv')); ?>

        </div>

        <br><br>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-default btn-sm">SAVE</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <?php echo Form::close(); ?>

    <!-- Content -->


    <script type="text/javascript">
        tinymce.init({
            selector: '.myeditablediv',
            plugins: "lists image",

        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>