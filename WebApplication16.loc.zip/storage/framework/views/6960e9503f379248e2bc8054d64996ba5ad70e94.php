<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->
    <div>
        <table width="100%" height="50px">
            <tr>
                <td>
                    <strong><p>Business Analitic Tools</p></strong>
                </td>
                <td align="right" style="cursor:pointer" onclick="location.href='/categories/index'" onmouseover="this.style.fontSize='130%';" onmouseout="this.style.fontSize='100%';">
                    <p><span class="glyphicon glyphicon-wrench" aria-hidden="true" style="margin-right:5px;"></span>Edit</p>
                </td>
            </tr>
        </table>

        <hr style="border:1px solid black; margin-top:0px;">

        <div>
            <?php $__currentLoopData = $catt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p style="font-family:Times New Roman; margin-bottom:5px;"><span class=" glyphicon glyphicon-folder-open" aria-hidden="true" style="margin-right:10px;"></span><a href="/page/<?php echo e($cc->id); ?>" style="color:black;"><?php echo e($cc->name); ?></a></p>
                    <?php if(isset($cat) && ($cat == $cc->id)): ?>
                        <?php $__currentLoopData = $subb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="font-family:Calibri Light; margin:0px;"><span class=" glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-left:15px; margin-right:5px;"></span><a href="/page/1/<?php echo e($ss->id); ?>" style="color:black;"><?php echo e($ss->name); ?></a></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <hr style="border:1px dashed #aaaaaa">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


</div>