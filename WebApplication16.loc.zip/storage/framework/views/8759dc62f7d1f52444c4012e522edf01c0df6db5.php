<?php $__env->startSection('content'); ?>

    <div>
        <strong><?php echo e($content); ?></strong>
    </div>

    <table class="table-bordered" width="800px">
        <tr>
            <td>
                Login
            </td>
            <td>
                ---
            </td>
        </tr>
        <tr>
            <td>
                Password
            </td>
            <td>
                ---
            </td>
        </tr>
        <tr>
            <td>
                e-mail
            </td>
            <td>
                ---
            </td>
        </tr>
        <tr>
            <td>
                Name
            </td>
            <td>
                ---
            </td>
        </tr>
        <tr>
            <td>
                Surname
            </td>
            <td>
                ---
            </td>
        </tr>
        <tr>
            <td>
                Birth
            </td>
            <td>
                ---
            </td>
        </tr>
    </table>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.settings_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>