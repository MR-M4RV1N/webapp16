<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <!-- Контент -->
    <div align="center"> <!-- div для выравнивания по центру -->
        <!-- Кнопка -->
        <div align="left"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true" style="margin-right:10px;"></span><a href="/admin/page_categories_strategy_index">Back to category list</a></div><br>
        <!-- Список -->
        <table class="table table-bordered">
            <?php $__currentLoopData = $categories_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><p style="font-family:Times New Roman; margin-bottom:5px;"><span class="glyphicon glyphicon-list-alt" aria-hidden="true" style="margin-right:10px;"></span><?php echo e($sub->name); ?></p></td>
                    <td align="center" width="90px"><button onclick="location.href='/admin/categories_strategy_sub/edit/<?php echo e($sub->id); ?>/<?php echo e($cat); ?>'">Edit</button></td>
                    <td align="center" width="90px">
                        <?php echo Form::open(['method' => 'DELETE','route' => ['categories-strategy-sub-destroy', $sub->id, $cat],'style'=>'display:inline']); ?>

                        <?php echo Form::submit('Delete'); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div align="left">
            <button type="button" name="add" id="add" class="btn btn-default" onclick="location.href='/admin/categories_strategy_sub/create/<?php echo e($cat); ?>'">Add</button>
        </div>
    </div> <!-- / div для выравнивания по центру -->
    <!-- Content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>