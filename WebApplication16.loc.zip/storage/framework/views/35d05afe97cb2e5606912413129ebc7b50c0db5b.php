<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">

        <?php $__currentLoopData = $firm_canvas_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firm_canvas_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <table width="600px" class="table-bordered">
                <tr>
                    <td width="550px">
                        <?php echo e($firm_canvas_result->item); ?>

                    </td>
                    <td>
                        <a href="/my_page/firm_canvas_crud_edit/<?php echo e($cat); ?>/<?php echo e($canvas_block); ?>/<?php echo e($firm_canvas_result->id); ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                    </td>
                    <td>
                        <?php echo Form::open(['method' => 'DELETE','route' => ['firm_canvas_crud_destroy', $cat,  $canvas_block, $firm_canvas_result->id]]); ?>

                            <button type="submit" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span></button>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div style="margin-top:30px;">
            <div style="margin:5px 0px 10px 0px; text-align: center;"><a href="/my_page/firm_canvas_crud_create/<?php echo e($cat); ?>/<?php echo e($canvas_block); ?>" class="btn btn-default btn-xs"><span class=" glyphicon glyphicon-plus" aria-hidden="true" style="margin-right:5px;"></span>Pievienot</a></div>
        </div>



    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>