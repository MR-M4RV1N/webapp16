<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div>
        <h3>Добро пожаловать!</h3>
    </div>
    <br>


    <table class="table-bordered" width="100%">
        <tr height="30px">
            <td width="250px">
                <strong>Ваш логин:</strong>
            </td>
            <td width="400px" align="center">
                <?php echo e(Auth::user()->name); ?>

            </td>
            <td align="center">
                Редактировать профиль
            </td>
        </tr>

        <tr height="30px">
            <td>
                <strong>Документов в базе данных:</strong>
            </td>
            <td align="center">
                <?php echo e($user_firm_count); ?>

            </td>
            <td align="center">
                Открыть список
            </td>
        </tr>

        <tr height="30px">
            <td>
                <strong>Активный документ</strong>
            </td>
            <td align="center">
                <?php echo e($selected_firm_name); ?>

            </td>
            <td align="center">
                Изменить
            </td>
        </tr>

        <tr height="30px">
            <td>
                <strong>Прогресс этого документа:</strong>
            </td>
            <td align="center">
                <?php echo e($check_canvas_total); ?>/5
            </td>
            <td align="center">
                Открыть карту
            </td>
        </tr>
    </table>

    <br>

    <table width="100%" class="table-bordered">
        <tr height="30px">
            <td align="center">
                Открыть <?php echo e($selected_firm_name); ?>

            </td>
        </tr>
    </table>

    <br>
    <hr>
    <br>

    <table width="100%" class="table-bordered">
        <tr height="30px">
            <td align="center">
                Создать новый
            </td>
        </tr>
    </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.home_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>