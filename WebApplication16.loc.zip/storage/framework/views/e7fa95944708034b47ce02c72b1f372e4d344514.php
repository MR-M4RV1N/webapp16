<?php $__env->startSection('content'); ?>

    <strong><?php echo e($content); ?></strong><br><br>

    <table>
        <tr style="border-bottom: 3px double black;">
            <td>
                <strong>nikname</strong>
            </td>
            <td>
                <strong>email</strong>
            </td>
            <td>
                <strong>status</strong>
            </td>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="200px">
                    <?php echo e($user->name); ?>

                </td>
                <td width="200px">
                    <?php echo e($user->email); ?>

                </td>
                <td width="200px">
                    <?php echo e($user->type); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_users_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>