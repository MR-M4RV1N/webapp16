<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div align="center">
        <h3>Competitors</h3>
    </div>

    <div style="margin: 50px 30px 50px 30px;">
        <?php if(isset($table_models_text->text)): ?>
            <p style="text-indent: 20px;" align="justify"><?php echo e($table_models_text->text); ?></p>
        <?php endif; ?>
    </div>

    <?php if(isset($my_firm->name) and isset($competitors[0])): ?>
        <!-- Заглавие -->
        <div align="center">
            <strong>SIA „XXX” un konkurentu darbības salīdzinājums (CPM MATRIX)</strong>
            <a href="/my_page/page_competitors_edit/" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> Edit</a>
        </div>

        <br>

        <!-- Главная таблица -->
        <table class="table-bordered" width="90%" align="center">
            <tr>
                <td rowspan="2" align="center">
                    N.<br>
                    p.<br>
                    k.<br>
                </td>
                <td rowspan="2" align="center">Darbības kritērijs</td>
                <td colspan="<?php echo e($competitors_count); ?>" align="center">Uzņēmums un tā darbības vērtējums 5 baļļu sistēmā</td>
            </tr>
            <tr>
                <!-- Перебор имен конкурентов -->
                <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td align="center"><?php echo e($c->name); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Название моей фирмы -->
                <td align="center"><?php echo e($my_firm->name); ?></td>
            </tr>

            <!-- Перебор категорий -->
            <?php $i = 1?>
            <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td align="center"><?php echo e($i); ?></td>
                    <td><?php echo e($criteria->name); ?></td>

                    <!-- Перебор оценок конкурентов -->
                    <?php $kr = 'kr'.$i; ?>
                    <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td align="center"><?php echo e($c->$kr); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Перебор оценок моей фирмы -->
                    <td align="center"><?php echo e($my_firm->$kr); ?></td>
                </tr>
                <?php $i++ ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td colspan="2" align="right"> KOPĀ:</td>

                <!-- Общее число баллов у конкурентов -->
                <?php for($td_count = 0; $td_count < $competitors_count-1; $td_count++): ?>
                    <td align="center"><?php echo e($competitors_total[$td_count]); ?></td>
                <?php endfor; ?>

                <!-- Общее число баллов у своей фирмы -->
                <td align="center"><?php echo e($my_firm_total); ?></td>
            </tr>
        </table>
    <?php else: ?>
        <!-- Заглавие -->
        <div align="center">
            <strong>SIA „XXX” un konkurentu darbības salīdzinājums (CPM MATRIX)</strong>
        </div>

        <br>

        <!-- Была ли введена информация о моей фирме -->
        <?php if(isset($my_firm->name)): ?>
            <div align="center" style="margin-top:30px;">
                <s>1. You must create your firm data!</s> OK!
            </div>
        <?php else: ?>
            <div align="center" style="margin-top:30px;">
                1. You must create your firm data!
                <a href="/my_page/page_competitors_first_create" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Create</a>
            </div>
        <?php endif; ?>

        <!-- Была ли введена информация о моих конкурентах -->
        <?php if(isset($competitors[0])): ?>
            <div align="center" style="margin-top:30px;">
                <s>2. You must create your competitor data!</s> OK!
            </div>
        <?php else: ?>
            <div align="center" style="margin-top:30px;">
                2. You must create your competitor data!
                <a href="/my_page/page_competitors_crud_create" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Create</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>