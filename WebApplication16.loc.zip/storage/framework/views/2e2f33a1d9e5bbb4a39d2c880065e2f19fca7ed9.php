<?php $__env->startSection('content'); ?>

    <div align="center">
        <h4>PRIEKŠLIKUMI - <?php echo e($table_title); ?></h4>
    </div>

    <br><br>

    <div align="center">
        <div class="spoiler-text-2" align="left">
            <p style="text-indent: 20px;" align="justify">

            <table style="border:1px solid lightgrey" width="700px" align="center">
                <tr height="50px">
                    <td colspan="4" style="border-bottom:1px solid lightgrey">
                        <div style="margin-left:20px;">
                            <?php if(isset($table_title)): ?>
                                <?php echo e($table_title); ?>

                            <?php else: ?>
                                <?php echo e($category_name); ?>:
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" height="10px">

                    </td>
                </tr>

                <?php $i = 1; ?>
                <?php $__currentLoopData = $example; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr height="30px">
                        <td width="50px" align="right">
                            <?php echo e($i); ?>.
                        </td>
                        <td>
                            <div style="margin-left:10px;">
                                <?php echo e($e); ?>

                            </div>
                        </td>
                        <td width="40px" align="center">

                        </td>
                        <td width="40px" align="left">

                        </td>
                    </tr>
                    <?php $i++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            </p>
        </div>
    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.test_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>