<?php $__env->startSection('content'); ?>

    <div align="center">
        <h3><?php echo e($theories->title); ?></h3>
    </div>

    <br><br>


    <div style="margin: 30px;">
        <?php echo $theories->description ?>
    </div>

    <div style="margin: 30px;">
        <?php echo $theories->text ?>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.admin_categories_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>