<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div>
        <strong>Uzņēmuma nosaukums:</strong>
        <p><?php echo e($user_firm_result[0]->firm_name); ?></p>
    </div>

    <div>
        <strong>Uzņēmuma apraksts:</strong>
        <p><?php echo e($user_firm_result[0]->firm_description); ?></p>
    </div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.firms_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>