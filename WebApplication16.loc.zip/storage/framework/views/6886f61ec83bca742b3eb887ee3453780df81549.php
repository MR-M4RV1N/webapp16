<div id="treeview-wrapper" style="border-right:1px solid black; padding:30px 20px 30px 20px;">
    <!-- snipp --->

    <!-- / snipp -->
    <div style="color: #eeeeee; margin-top:50px;">
        <p style="font-family:Calibri Light; margin:0px;">
            <span class="glyphicon glyphicon-briefcase" aria-hidden="true" style="margin-left:15px; margin-right:5px;">

            </span>
            <a href="/page_all_firms" style="color: #eeeeee;">
                Uzņēmumu redaktors
            </a>
        </p>
    </div>


</div>