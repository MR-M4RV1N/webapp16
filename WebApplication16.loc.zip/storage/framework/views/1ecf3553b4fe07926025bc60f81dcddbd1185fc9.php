<?php $__env->startSection('content'); ?>
    <table width="1200px" align="center" style="margin-top:10px;">
        <tr align="center">
            <td width="45%" valign="middle">
                <?php echo $__env->make('partials.free.register1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>